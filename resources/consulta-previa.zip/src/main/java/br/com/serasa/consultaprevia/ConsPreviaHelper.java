package br.com.serasa.consultaprevia;

import br.com.serasa.helper.HelperImpl;
import br.com.serasa.helper.NoSuchActionException;

/**
 * Description of the Class
 * 
 * @author Bruno
 * @created 15 de Julho de 2003
 */
public class ConsPreviaHelper extends HelperImpl {

    /**
     * a��o consultar dados do solicitante na BD da Receita Federal
     */
    public final static String ACTION_CONSULT_PRE = "14";

    /**
     * a��o para testar formul�rio de solicita��o para Receita Federal
     */
    public final static String ACTION_CONSULT_PRE_TEST = "15";

    /**
     * Sets the action attribute of the ConsPreviaHelper object
     * 
     * @param action The new action value
     * @exception NoSuchActionException Description of the Exception
     */
    public void setAction(String action) throws NoSuchActionException {
        /*	if (ACTION_CONSULT_PRE.equals(action)) {
         command = new ConsPreviaConsultCommand();
         } else if (ACTION_CONSULT_PRE_TEST.equals(action)) {
         command = new ConsPreviaTestCommand();
         } else {
         throw new NoSuchActionException("ConsPreviaHelper.setAction: invalid action: " + action);
         }*/
    }
}
