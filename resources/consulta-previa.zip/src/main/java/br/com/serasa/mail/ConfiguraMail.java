package br.com.serasa.mail;

import java.util.Properties;

import javax.mail.MessagingException;

import org.owasp.esapi.CustomLogger;
import org.owasp.esapi.CustomLoggerFactory;

public class ConfiguraMail {
    private String smtpIpServer;

    private String remetente;

    private String destinatarios;

    private String userSmtpIpServer;

    private String senha;

    private CustomLogger log = CustomLoggerFactory.getLogger(this.getClass().getName());

    public ConfiguraMail() {

    }

    public ConfiguraMail(Properties properties) {
        log.info("===Entrou no ConfiguraMail =====");
        setSmtpIpServer(properties.getProperty("mail.host"));
        setRemetente(properties.getProperty("mail.from"));
        setDestinatarios(properties.getProperty("mail.to"));
        setUserSmtpIpServer(properties.getProperty("mail.usuario"));
        setSenha(properties.getProperty("mail.senha"));
        log.info("===Saiu do ConfiguraMail =====");
    }

    private void setSmtpIpServer(String smtpIpServer) {
        this.smtpIpServer = smtpIpServer;
    }

    public String getSmtpIpServer() {
        return this.smtpIpServer;
    }

    private void setRemetente(String remetente) {
        this.remetente = remetente;
    }

    public String getRemetente() {
        return this.remetente;
    }

    private void setDestinatarios(String destinatarios) {
        this.destinatarios = destinatarios;
    }

    public String getDestinatarios() {
        return this.destinatarios;
    }

    private void setUserSmtpIpServer(String userSmtpIpServer) {
        this.userSmtpIpServer = userSmtpIpServer;
    }

    public String getUserSmtpIpServer() {
        return this.smtpIpServer;
    }

    private void setSenha(String senha) {
        this.senha = senha;
    }

    public String getSenha() {
        return this.senha;
    }

    public void enviaMail(String assunto, String conteudo) throws MessagingException {
        SmtpData mailSenderBean = SmtpData.getInstance(smtpIpServer, this.userSmtpIpServer, senha);
        SendMail smtpMailSender = SendMail.getInstance(mailSenderBean);
        MailBean mailBean = new MailBean();
        mailBean.setRemetente(this.remetente);
        mailBean.splitAndAddDestinatarios(this.destinatarios);
        mailBean.setAssunto(assunto);
        mailBean.setConteudo(conteudo);
        smtpMailSender.sendMail(mailBean);
    }
}
