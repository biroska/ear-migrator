/*
 * Created on 26/01/2004
 */
package br.com.serasa.tools;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * @author dadario
 */
public class Data {

    /**
     * Formato da data: dd/MM/yyyy - HH:mm:ss
     */
    public final static Formato DATA_COMPLETA_24H = new Formato("dd/MM/yyyy - HH:mm:ss");

    /**
     * Formato da data: dd/MM/yyyy - hh:mm:ss a
     */
    public final static Formato DATA_COMPLETA_12H_AM_PM = new Formato("dd/MM/yyyy - hh:mm:ss a");

    /**
     * Formato da data: yyyy-MM-dd HH:mm:ss
     */
    public final static Formato DATA_TIMESPAM = new Formato("yyyy-MM-dd HH:mm:ss");

    /**
     * Formato da data: dd/MM/yyyy
     */
    public final static Formato DATA_SIMPLES = new Formato("dd/MM/yyyy");

    /**
     * Formato da data: yyyy-MM-dd Se desejar com horario. Utilize DATA_TIMESPAM
     */
    public final static Formato DATA_BANCO = new Formato("yyyy-MM-dd");

    /**
     * Formato da data ddMMyyyy
     */
    public static final Formato DATA_SEM_SEPARADOR = new Formato("ddMMyyyy");

    private SimpleDateFormat format;

    private Data(Formato formato) {
        format = new SimpleDateFormat(formato.toString());
    }

    /**
     * Obtem a data atual do sistema no formato indicado.
     * 
     * @param formato Formato ao qual ser� formatada a data para String
     * @return String da data no formato pretendido
     */
    public static String dataAtual(Formato formato) {
        Data dataObj = new Data(formato);
        return dataObj.dataAtual();
    }

    /**
     * Formata um objeto Date em String, no formato referenciado
     * 
     * @param formato Formato ao qual ser� formatada a data para String
     * @param data java.uti.Date
     * @return String formatada no modelo da data pretendida
     */
    public static String formate(Formato formato, Date data) {
        Data dataObj = new Data(formato);
        return dataObj.format(data);
    }

    /**
     * Converte uma data em String para o objeto java.util.Date
     * 
     * @param formato Formato ao qual est� formatada a data
     * @param data String em formato de data
     * @return java.util.Date
     * @throws ParseException Caso o formato da data para convers�o n�o seja valida.
     */
    public static Date parse(Formato formato, String data) throws ParseException {
        Data dataObj = new Data(formato);
        return dataObj.parse(data);
    }

    /**
     * Converte uma data de String para outra String no formato indicado.
     * 
     * @param data Campo em string representando uma data
     * @param antigo Formato ao qual a data est� formatada na string
     * @param novo Formato ao qual deseja converter para o novo formato
     * @return Data formatada no formato indicado no campo novo
     * @throws ParseException Caso o formato da data para convers�o n�o seja valida.
     */
    public static String convert(String data, Formato antigo, Formato novo) throws ParseException {
        Data dataObj = new Data(antigo);
        return dataObj.convert(data, novo);
    }

    private String convert(String data, Formato novo) throws ParseException {
        Date antiga = parse(data);
        format = new SimpleDateFormat(novo.toString());
        return format.format(antiga);
    }

    private Date parse(String data) throws ParseException {
        return format.parse(data);
    }

    private String format(Date data) {
        if (Verify.isNull(data)) {
            return "";
        }
        return format.format(data);
    }

    private String dataAtual() {
        return format.format(new Date());
    }

    public static boolean depoisDe(Date data, Date dataComparar) {
        return data.after(dataComparar);
    }

    public static boolean antesDe(Date data, Date dataComparar) {
        return data.before(dataComparar);
    }

}

class Formato {

    private String formato;

    protected Formato(String formato) {
        this.formato = formato;
    }

    @Override
    public String toString() {
        return formato;
    }
}
