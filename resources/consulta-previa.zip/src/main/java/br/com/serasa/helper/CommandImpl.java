/*
 * Created on 22/08/2003
 */
package br.com.serasa.helper;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.owasp.esapi.CustomLogger;
import org.owasp.esapi.CustomLoggerFactory;

import br.com.serasa.consultaprevia.ConsultaPreviaFiltro;
import br.com.serasa.consultaprevia.bean.validator.ErroList;
import br.com.serasa.consultaprevia.bean.validator.TradutorDeErros;
import br.com.serasa.mail.ConfiguraMail;

/**
 * Classe abstrata implementando alguns m�todos do Command. Cria a lista de erros e a mant�m. Subclasses dever�o
 * adicionar erros a essa lista atrav�s do m�todo addError().
 * 
 * @author riko
 * @created 10 de outubro de 2003
 * 
 */
public abstract class CommandImpl implements Command {

    private List<String> errorList;

    private CustomLogger log = CustomLoggerFactory.getLogger(this.getClass().getName());

    protected boolean noErrors() {
        return errorList == null || errorList.isEmpty();
    }

    public void addError(String errorMessage) {
        if (errorList == null) {
            errorList = new ArrayList<String>();
            TradutorDeErros.addTraducao(ConsultaPreviaFiltro.class.getName(), TradutorDeErros.DADOS_DO_RESPONSAVEL);
        }
        errorList.add(errorMessage);
    }

    public String[] getErrors() {
        return errorList == null ? null : (String[]) errorList.toArray(new String[errorList.size()]);
    }

    protected void addErrorsFromArray(String[] errors) {
        if (errors != null) {
            for (int i = 0; i < errors.length; i++) {
                addError(errors[i]);
            }
        }
    }

    protected void sendMail(Map<String, String> paramMap, String sessionId) {
        ConfiguraMail ca = new ConfiguraMail();
        try {
            ca.enviaMail("aa", "bb");
        } catch (Exception e) {
            log.info(e.getMessage());
        }
    }

    protected static final String TAGLIBRARY_READONLY = "br.com.serasa.taglibrary.readOnly";

    protected static final String TAGLIBRARY_READONLY_SRF = "br.com.serasa.taglibrary.readOnlySRF";

    /**
     * @param erros
     */
    @SuppressWarnings("unchecked")
    protected void addErros(ErroList erros) {
        List<Object> ordem = erros.ordemDosErros();
        for (Iterator<Object> iter = ordem.iterator(); iter.hasNext();) {
            String cadaNome = (String) iter.next();

            addError(TradutorDeErros.descricaoErro(cadaNome));
            addErrors(erros.erros(cadaNome));
        }
    }

    /**
     * @param list
     */
    private void addErrors(List<String> list) {
        errorList.addAll(list);
    }

    /**
     * @param request
     * @param userBean
     */
    protected void setAttributeBeanInRequest(HttpServletRequest request) {

    } 
}
