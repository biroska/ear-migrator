/*
 * Created on 16/12/2003
 */
package br.com.serasa.exception;

import java.util.HashMap;
import java.util.Map;

/**
 * Mapeia as mensagens de erros do COnsulta Previa. Estava vindo com caracteres ? nos acentos, por isso mapeamos para
 * acentos em HTML. Atualizar os codigos caso ocorra alteracao.
 * 
 * @author riko PH - 14/01/2010: retirei todos os acentos HTML, pois estavam dando erro na hora de fazer o parse do xml
 */
public class ErrorsMap {

    private final static Map<String, String> errors = new HashMap<String, String>();

    static {
        //Erros internos
        errors.put("-1", "XML mal-formado.: ");
        errors.put("-2", "Formato de dados inv�lido.: ");
        errors.put("-3", "Erro Interno na Consulta Previa.: ");
        errors.put("-4", "Erro interno objeto null.: ");
        errors.put("-5", "Erro SSLSerasaSocketException.: ");
        errors.put("-6", "Parametro xml n�o enviado.: ");

        //Erros enviados pela receita federal
        errors.put("01", "CPF informado inv&aacute;lido. Emiss&atilde;o do Certificado n&atilde;o permitida.");
        errors.put("02",
            "CPF informado inexistente nas bases de dados da SRF. Emiss&atilde;o do certificado n&atilde;o permitida.");
        errors.put(
            "03",
            "O CPF informado se encontra na situa&ccedil;&atilde;o cadastral de CANCELADO nas bases de dados da SRF. Emiss&atilde;o do certificado n&atilde;o permitida.");
        errors.put(
            "04",
            "A data de nascimento informada &eacute; divergente da existente nas bases de dados da SRF. Emiss&atilde;o do certificado n&atilde;o permitida.");
        errors.put(
            "05",
            "O n&uacute;mero do t&iacute;tulo de eleitor n&atilde;o foi informado. Emiss&atilde;o do certificado n&atilde;o permitida.");
        errors.put(
            "06",
            "O n&uacute;mero do t&iacute;tulo de eleitor informado &eacute; divergente do existente nas bases de dados da SRF. Emiss&atilde;o do certificado n&atilde;o permitida.");
        errors.put("20", "CNPJ informado inv&aacute;lido. Emiss&atilde;o do certificado n&atilde;o permitida.");
        errors.put("21",
            "CPF do respons&aacute;vel informado inv&aacute;lido. Emiss&atilde;o do certificado n&atilde;o permitida.");
        errors.put("22",
            "CNPJ informado inexistente nas bases de dados da SRF. Emiss&atilde;o do certificado n&atilde;o permitida.");
        errors.put(
            "23",
            "CPF do respons&aacute;vel informado inexistente nas bases de dados da SRF. Emiss&atilde;o do certificado n&atilde;o permitida.");
        errors.put(
            "24",
            "O CNPJ informado se encontra na situa&ccedil;&atilde;o cadastral de INAPTO nas bases de dados da SRF. Emiss&atilde;o do certificado n&atilde;o permitida.");
        errors.put(
            "25",
            "O CNPJ informado se encontra na situa&ccedil;&atilde;o cadastral de CANCELADO nas bases de dados da SRF. Emiss&atilde;o do certificado n&atilde;o permitida.");
        errors.put(
            "26",
            "O CNPJ informado se encontra na situa&ccedil;&atilde;o cadastral de SUSPENSO nas bases de dados da SRF. Emiss&atilde;o do certificado n&atilde;o permitida.");
        errors.put(
            "27",
            "O CPF do respons&aacute;vel informado n&atilde;o &eacute; igual ao do respons&aacute;vel pela empresa nas bases de dados da SRF. Emiss&atilde;o do certificado n&atilde;o permitida.");
        errors.put(
            "28",
            "O CPF do respons&aacute;vel informado se encontra na situa&ccedil;&atilde;o cadastral de CANCELADO nas bases de dados da SRF. Emiss&atilde;o do certificado n&atilde;o permitida.");
        errors.put(
            "29",
            "A data de nascimento do respons&aacute;vel informada &eacute; divergente da existente nas bases de dados da SRF. Emiss&atilde;o do certificado n&atilde;o permitida.");
        errors.put(
            "40",
            "O T&iacute;tulo de Eleitor informado possui mais de 12 d&iacute;gitos. Emiss&atilde;o do certificado n&atilde;o permitida.");
        errors.put("41",
            "O CNPJ informado possui mais de 14 d&iacute;gitos. Emiss&atilde;o do certificado n&atilde;o permitida.");
        errors.put("42",
            "O CPF informado possui mais de 11 d&iacute;gitos. Emiss&atilde;o do certificado n&atilde;o permitida.");
        errors.put(
            "43",
            "A data de nascimento deve&nbsp; ser informada com 8 d&iacute;gitos, no formato DDMMAAAA. Emiss&atilde;o do certificado n&atilde;o permitida.");
        errors.put("50", "Tipo inv&aacute;lido. Emiss&atilde;o do certificado n&atilde;o permitida.");
        errors.put("51", "Tipo inv&aacute;lido. Emiss&atilde;o do certificado n&atilde;o permitida.");
        errors.put(
            "52",
            "N&uacute;mero do T&iacute;tulo de Eleitor informado n&atilde;o &eacute; num&eacute;rico. Emiss&atilde;o do certificado n&atilde;o permitida.");
        errors.put(
            "53",
            "N&uacute;mero do CNPJ informado n&atilde;o &eacute; num&eacute;rico. Emiss&atilde;o do certificado n&atilde;o permitida.");
        errors.put(
            "54",
            "N&uacute;mero do CPF informado n&atilde;o &eacute; num&eacute;rico. Emiss&atilde;o do certificado n&atilde;o permitida.");
        errors.put(
            "55",
            "Data de nascimento informada cont&eacute;m caractere(s) inv&aacute;lido(s). Emiss&atilde;o do certificado n&atilde;o permitida.");
        errors.put("90", "Sistema temporariamente fora do ar. Tente mais tarde.");
        errors.put("91", "Sistema temporariamente fora do ar. Tente mais tarde.");
        errors.put("92", "Sistema temporariamente fora do ar. Tente mais tarde.");
        errors.put("93", "Sistema temporariamente fora do ar. Tente mais tarde.");
        errors.put("94", "Sistema temporariamente fora do ar. Tente mais tarde.");
        errors.put("95", "Sistema temporariamente fora do ar. Tente mais tarde.");
        errors.put("96", "Sistema temporariamente fora do ar. Tente mais tarde.");
        errors.put("97", "Sistema temporariamente fora do ar. Tente mais tarde.");
        errors.put("98", "Servidor com problemas. Tente mais tarde.");
        errors.put("99", "Certificado n&atilde;o autorizado.");
    }

    public static String getMsgError(String errorCode) {
        String errorMsg = errors.get(errorCode);
        return errorMsg == null ? "Ocorreu um erro executando consulta. C&oacute;digo do erro: " + errorCode : errorMsg;
    }
}
