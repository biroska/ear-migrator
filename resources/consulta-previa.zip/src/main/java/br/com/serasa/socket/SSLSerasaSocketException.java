/*
 * Created on 07/10/2003
 */
package br.com.serasa.socket;

/**
 * @author riko
 * 
 */
public class SSLSerasaSocketException extends Exception {

    /**
     * 
     */
    private static final long serialVersionUID = -2699436268682425206L;

    public SSLSerasaSocketException(String msgError) {
        super(msgError);
    }
}
