/*
 * Created on 27/02/2004
 */
package br.com.serasa.consultaprevia.bean.validator.filtro;

/**
 * @author riko
 * 
 */
public class FiltroVazio extends Filtro {

    public static final Filtro INSTANCE = new FiltroVazio();

    // Por defini��o este filtro n�o faz nada
    @Override
    public void valida(Object bean) {}

}
