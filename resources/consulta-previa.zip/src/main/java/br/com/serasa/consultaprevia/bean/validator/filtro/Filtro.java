/*
 * Created on 20/02/2004
 */
package br.com.serasa.consultaprevia.bean.validator.filtro;

import br.com.serasa.consultaprevia.bean.validator.ErroList;
import br.com.serasa.tools.Cleaner;
import br.com.serasa.tools.Verify;

/**
 * @author dadario
 * 
 */
public abstract class Filtro {

    protected ErroList erros;

    public abstract void valida(Object bean);

    protected String limparCampoEUpperCase(String valor) {
        return valor == null ? valor : limparCampo(valor).toUpperCase();
    }

    protected String limparCampo(String valor) {
        if (Verify.isEmpty(valor)) {
            return valor;
        }
        String retorno = Cleaner.removeAspas(valor);
        return Cleaner.trocaCaracteresEspeciais(retorno);
    }

    /**
     * @param erros
     */
    public void setErros(ErroList erros) {
        this.erros = erros;
    }

    protected void addErro(String erro) {
        erros.add(erro);
    }

}
