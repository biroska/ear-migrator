package br.com.serasa.servlets;

import static br.com.serasa.consultaprevia.ConsPreviaBD.CODIGO_RETORNO_CPF_CNPJ_SUCESSO;
import static br.com.serasa.consultaprevia.ConsPreviaBD.VALOR_RETORNO_DADO_SEM_VALIDACAO;

import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Enumeration;
import java.util.Map;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManagerFactory;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringEscapeUtils;
import org.owasp.esapi.CustomLogger;
import org.owasp.esapi.CustomLoggerFactory;
import org.owasp.esapi.ESAPI;

import br.com.serasa.bd.QueryException;
import br.com.serasa.bean.bdconnection.BDConnectionBean;
import br.com.serasa.consultaprevia.ConsPreviaBD;
import br.com.serasa.consultaprevia.ConsPreviaConsultCommand;
import br.com.serasa.consultaprevia.bean.ConsPreviaBean;
import br.com.serasa.consultaprevia.bean.KeyStoreBean;
import br.com.serasa.consultaprevia.bean.ProxyBean;
import br.com.serasa.consultaprevia.bean.ReceitaBean;
import br.com.serasa.exception.NaoConectouNaReceitaException;
import br.com.serasa.pki.util.BCProviderUtil;
import br.com.serasa.servlets.bean.ControllerBean;
import br.com.serasa.servlets.bean.ErrorBean;
import br.com.serasa.util.DataUtil;

/**
 * Nova vers�o do controller, utilizando nova interface de Helper.
 * 
 * @author riko
 * 
 * @created 10 de Outubro de 2003
 */
public class Controller extends BDServlet {

    private static final String SUCESSO_CONS_SIMPLES = "60";

    private static final long serialVersionUID = 195801594800198102L;

    private CustomLogger log = CustomLoggerFactory.getLogger(this.getClass().getName());

    private SSLSocketFactory factory = null;
    
    ResourceBundle msgProperties;
    
    /**
     * Inicializa um Map contendo os par�metros de inicializa��o desse servlet (definidos no web.xml).
     * 
     * @exception ServletException Description of the Exception
     */
    @Override
    public void init() throws ServletException {
        super.init();
        BCProviderUtil.installBCProvider();

        Enumeration<?> enumeration = getInitParameterNames();

        while (enumeration.hasMoreElements()) {
            final String keyValue = (String) enumeration.nextElement();
            initParameterMap.put(keyValue, getInitParameter(keyValue));
        }

        for (Map.Entry<String, String> entry : initParameterMap.entrySet()) {
            log.info("{} / {}", entry.getKey(), entry.getValue());
        }

        //mensagens de erros
        //ResourceBundle msgProperties;
        try {
            msgProperties = ResourceBundle.getBundle("mensagens");
        } catch (MissingResourceException e) {
            log.error("arquivo de propridades de mensagens de erros inexistente!");
        }

        readKeystore();
    }

    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        doPost(request, response);
    }

    /**
     * Os par�metros principais (action, helper, nextPage etc) s�o encapsulados sempre em um ControllerBean, que � ent�o
     * inserido no HttpRequest. <BR>
     * Dependendo da a��o e helper, executa-se o Helper correspondente, setando os JavaBeans e action espec�ficos. <BR>
     * Faz o dispatch para pr�xima view.
     */
    @Override
    public void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException {
        log.info(">Controller.doPost()");

        String reloadKeystore = req.getParameter("reloadKeystore");
        log.info("reloadKeystore: {}", reloadKeystore);
        if (reloadKeystore != null && Boolean.valueOf(reloadKeystore)) {
            readKeystore();
        }

        try {
            ControllerBean controllerBean = createControllerBean(req);

            // out = respota a ser enviada
            ServletOutputStream out = resp.getOutputStream();
            if ((validateControllerBean(controllerBean))) {
                String codigo = "";
                String mensagem = "";
                String conteudo = "";

                try {
                    ConsPreviaConsultCommand consulta = new ConsPreviaConsultCommand(req, initParameterMap,
                            this.getFactory(), msgProperties);
                    codigo = ESAPI.encoder().encodeForHTML(StringEscapeUtils.unescapeHtml(consulta.getCodigo()));
                    mensagem = ESAPI.encoder().encodeForHTML(StringEscapeUtils.unescapeHtml(consulta.getMensagem()));
                    conteudo = ESAPI.encoder().encodeForHTML(
                        StringEscapeUtils.unescapeHtml(consulta.getConteudoRetorno()));
                } catch (NaoConectouNaReceitaException e) {
                    ConsPreviaBean consPreviaBean = e.getConsPreviaBean();
                    log.info("Nao conseguiu se conectar com a Receita, procurar no banco {}", consPreviaBean.toString());
                    String nomeBd = buscarNomeNoBanco(consPreviaBean);
                    codigo = CODIGO_RETORNO_CPF_CNPJ_SUCESSO;
                    if (VALOR_RETORNO_DADO_SEM_VALIDACAO.equals(nomeBd)) {
                        log.info("Valor nao foi encontrado no DBCICLO, retornar default dados sem validacao");
                        mensagem = VALOR_RETORNO_DADO_SEM_VALIDACAO;
                        conteudo = VALOR_RETORNO_DADO_SEM_VALIDACAO;
                    } else {
                        log.info("Valor encontrado no DBCICLO, retornar: {}", nomeBd);
                        mensagem = nomeBd;
                        conteudo = nomeBd;
                    }
                }

                // colocando encodeForXml pq estava dando pau qdo tinha html entity no xml
                String c = conteudo == null ? "" : conteudo;
                
                String textoFormatado = SUCESSO_CONS_SIMPLES.equals(codigo) ? DataUtil.formatarTextoConsultaSimples( mensagem ) : mensagem;

                /* Eh feio, mas nao remover senao acusarah flaw media de Veracode 
                 * A correcao seria realizar o encoder na linha out.print( xmlString.toString() ); 
                 * Mas isso quebra os consumidores do consulta previa, tendo que alterar todos eles. */
                StringBuffer xmlString = new StringBuffer("<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?>");
                xmlString.append("<consprev>")
	                         .append("<tipo-msg>RESP</tipo-msg>")
	                         .append("<codigo>").append( ESAPI.encoder().encodeForXML( codigo ) ).append("</codigo>")
	                         .append("<texto>").append( ESAPI.encoder().encodeForXML(  textoFormatado ) ).append("</texto>")
	                         .append("<texto-serpro>").append( ESAPI.encoder().encodeForXML( c ) ).append("</texto-serpro>")
                		 .append("</consprev>");

                log.info("xmlResposta: {}", xmlString.toString() );
                out.print( xmlString.toString() );
            } else {
                out.print(xmlResposta("-6", "Parametro xml nao enviado", ""));
            }
        } catch (Exception e) {
            log.error("Erro Inesperado: ", e);
        }
    }

    private String buscarNomeNoBanco(ConsPreviaBean consPreviaBean) throws ServletException {
        Connection conn = null;

        try {
            conn = getConnection();

            BDConnectionBean connectionBean = createBDConnectionBeanFromMap(initParameterMap, conn);
            ConsPreviaBD conspreviabd = new ConsPreviaBD(consPreviaBean);

            return conspreviabd.consultaDadosCiclo(connectionBean);
        } catch (SQLException e) {
            log.error("Erro ao ler dados do banco: ", e);
        } catch (QueryException e) {
            log.error("Erro ao ler dados do banco: ", e);
        } finally {
            closeConnection(conn);
        }

        return VALOR_RETORNO_DADO_SEM_VALIDACAO;
    }

    @Override
    protected Connection getConnection() throws SQLException {
        Connection connection = super.getConnection();
        log.info("Conexao aberta {}", connection);
        return connection;
    }

    @Override
    protected void closeConnection(Connection conn) {
        log.info("Fechando conexao {}", conn);
        super.closeConnection(conn);
    }

    private String xmlResposta(String codigo, String texto, String conteudoRetorno) {
        String textoFormatado = SUCESSO_CONS_SIMPLES.equals(codigo)
                ? DataUtil.formatarTextoConsultaSimples(texto)
                : texto;

        StringBuffer xmlString = new StringBuffer("<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?>");
        xmlString.append("<consprev><tipo-msg>RESP</tipo-msg><codigo>").append(codigo).append("</codigo><texto>")
                .append(textoFormatado).append("</texto>").append("<texto-serpro>").append(conteudoRetorno)
                .append("</texto-serpro></consprev>");

        return xmlString.toString();
    }

    /**
     * Cria e insere os dados em um ControllerBean. Este bean serve apenas para passar os dados principais entre as View
     * 
     * @return Retorna um ControllerBean contendo os valores preenchidos
     */
    private ControllerBean createControllerBean(HttpServletRequest request) {
        log.info("Controller.createControllerBean()");
        ControllerBean controllerBean = new ControllerBean();
        controllerBean.setXml(request.getParameter("xml"));
        // formatDtNow(controllerBean);
        return controllerBean;
    }

    /**
     * Valida os dados do ControllerBean, se est�o preenchidos ou n�o.
     * 
     * @param controllerBean Bean a ser validado
     * @return Retorna true se ok, false c.c.
     */
    private boolean validateControllerBean(ControllerBean controllerBean) {
        if (controllerBean == null) {
            return false;
        }

        if (DataUtil.isEmpty(controllerBean.getXml())) {
            return false;
        }

        return true;
    }

    /**
     * Redireciona para page.
     * 
     * @param page nome da pr�xima p�gina a ser redirecionada
     */
    protected void dispatch(HttpServletRequest request, HttpServletResponse response, String page)
            throws ServletException, IOException {
        RequestDispatcher dispatcher = getServletContext().getRequestDispatcher(page);
        dispatcher.forward(request, response);
    }

    /**
     * Se ocorrer erro, direciona para p�gina de erroGeral.jsp
     */
    protected void dispatchError(HttpServletRequest request, HttpServletResponse response, String errorMessage)
            throws ServletException, IOException {
        ErrorBean errorBean = new ErrorBean(errorMessage);
        request.setAttribute("errorBean", errorBean);
        RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/erroGeral.jsp");
        dispatcher.forward(request, response);
    }

    private void readKeystore() throws ServletException {
        log.info(">readKeystore()");
        Connection conn = null;

        try {
            conn = getConnection();

            BDConnectionBean connectionBean = createBDConnectionBeanFromMap(initParameterMap, conn);
            SSLSocketFactory factory = null;

            SSLContext ctx = SSLContext.getInstance("TLS");
            log.info("KeyManagerFactory.getDefaultAlgorithm()={}", KeyManagerFactory.getDefaultAlgorithm());
            KeyManagerFactory kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
            log.info("TrustManagerFactory.getDefaultAlgorithm()={}", TrustManagerFactory.getDefaultAlgorithm());
            TrustManagerFactory tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());

            ProxyBean proxyBean = new ProxyBean(initParameterMap);
            ReceitaBean receitaBean = new ReceitaBean(initParameterMap);
            ConsPreviaBean consPreviaBean = new ConsPreviaBean();
            ConsPreviaBD conspreviabd = new ConsPreviaBD(consPreviaBean, receitaBean, proxyBean, initParameterMap,
                    factory, msgProperties);
            KeyStoreBean keystorebean = conspreviabd.getKeyStoreFromBD(connectionBean);

            tmf.init(keystorebean.getKeystore());
            kmf.init(keystorebean.getKeystore(), keystorebean.getPassword().toCharArray());
            ctx.init(kmf.getKeyManagers(), tmf.getTrustManagers(), null);
            factory = ctx.getSocketFactory();
            this.setFactory(factory);
        } catch (UnrecoverableKeyException e) {
            log.error("Erro ao ler keystore: ", e);
        } catch (KeyManagementException e) {
            log.error("Erro ao ler keystore: ", e);
        } catch (NoSuchAlgorithmException e) {
            log.error("Erro ao ler keystore: ", e);
        } catch (KeyStoreException e) {
            log.error("Erro ao ler keystore: ", e);
        } catch (CertificateException e) {
            log.error("Erro ao ler keystore: ", e);
        } catch (SQLException e) {
            log.error("Erro ao ler  keystore: ", e);
        } catch (QueryException e) {
            log.error("Erro ao ler keystore: ", e);
        } catch (IOException e) {
            log.error("Erro ao ler keystore: ", e);
        } catch (InvalidKeyException e) {
            log.error("Erro ao ler keystore: ", e);
        } catch (IllegalBlockSizeException e) {
            log.error("Erro ao ler keystore: ", e);
        } catch (BadPaddingException e) {
            log.error("Erro ao ler keystore: ", e);
        } catch (NoSuchProviderException e) {
            log.error("Erro ao ler keystore: ", e);
        } catch (NoSuchPaddingException e) {
            log.error("Erro ao ler keystore: ", e);
        } finally {
            closeConnection(conn);
        }
    }

    public SSLSocketFactory getFactory() {
        return factory;
    }

    public void setFactory(SSLSocketFactory factory) {
        this.factory = factory;
    }
}
