/*
 * Created on 18/02/2004
 */
package br.com.serasa.tools;

// import br.com.serasa.bean.user.RepresentanteBean;

/**
 * @author dadario
 * 
 */
public class Verify {

    private static final String EM_BRANCO = "(EM BRANCO)";

    private static final String CLIENTE_PF = "1";

    private static final String CLIENTE_PJ = "2";

    private static final String CLIENTE_SERVIDOR = "3";

    private static final String CLIENTE_SPB = "4";

    private static final String EQUIPAMENTO_APLICACAO = "5";

    private static final String ASSINATURA_DE_CODIGO = "6";

    private static final String CONTROLADOR_DE_DOMINIO = "7";

    public static boolean isEmpty(String valor) {
        return isNull(valor) || valor.trim().equals("");
    }

    public static boolean isNotNull(Object objeto) {
        return !isNull(objeto);
    }

    public static boolean isNull(Object objeto) {
        return objeto == null;
    }

    public static boolean isPessoaFisica(String tipo) {
        return CLIENTE_PF.equals(tipo);
    }

    public static boolean isPessoaJuridica(String tipo) {
        return CLIENTE_PJ.equals(tipo);
    }

    public static boolean isServidor(String tipo) {
        return CLIENTE_SERVIDOR.equals(tipo) || EQUIPAMENTO_APLICACAO.equals(tipo) || ASSINATURA_DE_CODIGO.equals(tipo)
               || CONTROLADOR_DE_DOMINIO.equals(tipo);
    }

    public static boolean isServidorAssinaturaCodigo(String tipo) {
        return ASSINATURA_DE_CODIGO.equals(tipo);
    }

    public static boolean isControladorDeDominio(String tipo) {
        return CONTROLADOR_DE_DOMINIO.equals(tipo);
    }

    public static boolean isSpb(String tipo) {
        return CLIENTE_SPB.equals(tipo);
    }

    public static boolean isNumber(String valor) {
        return valor.matches("\\d+");
    }


    /* public static boolean isPjouServerInConsPrevia(String subProcesso, String tipoFormulario) {
     return (isServidor(tipoFormulario) || isPessoaJuridica(tipoFormulario))
     && (SUBPROCESSO_CONST_PREVIA.equals(subProcesso) || SUBPROCESSO_CONST_ANFAC.equals(subProcesso) || SUBPROCESSO_PROJ_ECNPJ.equals(subProcesso)
     || SUBPROCESSO_PROJ_SRFA3.equals(subProcesso));
     }*/

    public static boolean isDocumentValid(String numeroDocumento, String digitoDocumento) {
        if (Verify.isEmpty(numeroDocumento)) {
            return false;
        }
        try {
            String dvDoc = digitoDocumento == null ? "" : digitoDocumento.trim();
            int dvDocLength = dvDoc.length();

            String rgComZeros = Formatter.adicioneZerosAFrente(numeroDocumento, 15 - dvDocLength);
            rgComZeros += dvDoc;

            if (rgComZeros.length() > 15) {
                return false;
            }

            /*
             if(rgComZeros.replaceAll("0", "").trim().equals("")) {
             return false;
             }
             */

            return true;
        } catch (IllegalArgumentException iae) {
            return false;
        }
    }

    /*public static boolean isRepresentanteBeanEmpty(RepresentanteBean representanteBean) {
     if(Verify.isNull(representanteBean)) {
     return true;
     }

     return Verify.isEmpty(representanteBean.getNome())
     && Verify.isEmpty(representanteBean.getCpf())
     && Verify.isEmpty(representanteBean.getNumDoc())
     && Verify.isEmpty(representanteBean.getDvDoc())
     && Verify.isEmpty(representanteBean.getOrgaoExpedidor())
     && Verify.isEmpty(representanteBean.getCargo());
     }*/

    /**
     * @param valor
     * @return
     */
    public static boolean isOuEmBranco(String campoOu) {
        return isEmpty(campoOu) || EM_BRANCO.equalsIgnoreCase(campoOu);
    }

    public static boolean isSRF(String subProcesso) {
        if (!isEmpty(subProcesso)) {
            switch (Integer.parseInt(subProcesso)) {
                case 13:
                case 29:
                case 30:
                case 31:
                case 32:
                case 33:
                case 35:
                case 113:
                case 37:
                case 38:
                case 42:
                case 43:
                case 47:
                case 48:
                case 49:
                case 53:
                case 54:
                    return true;
            }
        }
        return false;
    }

    // verifica CEP - aceita letras e numeros, pois CEPs na Argentina contem
    // letras, por exemplo (sim, um argentinho ja tentou fazer uma requisicao)
    public static boolean isValidCep(String cep) {
        if (isEmpty(cep))
            return false;

        char[] v = cep.toCharArray();
        for (int i = 0; i < v.length; i++) {
            if (!Character.isLetterOrDigit(v[i]))
                return false;
        }
        return true;
    }

    //verifica se uma data (emitida como parametro String eh uma data de conteudo
    // valido ou nao. A data deve ser enviada em formato DDMMAAAA
    public static boolean isValidDate(String date) {

        int dia, mes, ano;
        boolean res = false;

        //contagem do numero de caracteres
        if (date.length() != 8)
            return res;

        dia = Integer.parseInt(date.substring(0, 2));
        mes = Integer.parseInt(date.substring(2, 4));
        ano = Integer.parseInt(date.substring(4, date.length()));

        if (mes <= 0 || mes > 12 || dia <= 0 || dia > 31 || ano < 0)
            return res;

        if (mes == 1 || mes == 3 || mes == 5 || mes == 7 || mes == 8 || mes == 10 || mes == 12) {
            if (dia > 0 && dia <= 31) {
                res = true;
            }
        }

        else if (mes == 4 || mes == 6 || mes == 9 || mes == 11) {
            if (dia > 0 && dia <= 30) {
                res = true;
            }
        }

        else if (mes == 2) {
            if (ano % 4 == 0) {
                if (dia > 0 && dia <= 29)
                    res = true;
            } else {
                if (dia > 0 && dia <= 28)
                    res = true;
            }
        }

        return res;
    }

}
