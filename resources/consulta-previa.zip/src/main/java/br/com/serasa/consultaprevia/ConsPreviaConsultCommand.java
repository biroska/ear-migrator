package br.com.serasa.consultaprevia;

import java.util.Map;
import java.util.MissingResourceException;
import java.util.ResourceBundle;
import java.util.StringTokenizer;

import javax.net.ssl.SSLSocketFactory;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.owasp.esapi.CustomLogger;
import org.owasp.esapi.CustomLoggerFactory;

import br.com.serasa.consultaprevia.bean.ProxyBean;
import br.com.serasa.consultaprevia.bean.ReceitaBean;
import br.com.serasa.exception.NaoConectouNaReceitaException;
import br.com.serasa.exception.TrataErros;
import br.com.serasa.tools.Verify;
import br.com.serasa.util.DataUtil;

/**
 * Description of the Class
 * 
 * @author Bruno
 * @created 15 de Julho de 2003
 */
public class ConsPreviaConsultCommand extends ConsPreviaValidateCommand {

    private ResourceBundle msgProperties;

    private CustomLogger log = CustomLoggerFactory.getLogger(this.getClass().getName());

    private String codigo;

    private String mensagem;

    // mensagem do Serpro
    private String conteudoRetorno;

    private final int COD_RET_CONS_SIMP_EMP_MEIO_PORTE = 60;

    public ConsPreviaConsultCommand(HttpServletRequest request, Map<String, String> paramMap, SSLSocketFactory factory,
            ResourceBundle msgProperties) throws NaoConectouNaReceitaException {
        create(request, paramMap, factory, true, msgProperties);
    }

    public ConsPreviaConsultCommand(HttpServletRequest request, Map<String, String> paramMap, SSLSocketFactory factory,
            boolean contigencia, ResourceBundle msgProperties) throws NaoConectouNaReceitaException {
        create(request, paramMap, factory, contigencia, msgProperties);
    }

    private void create(HttpServletRequest request, Map<String, String> paramMap, SSLSocketFactory factory,
            boolean contigencia, ResourceBundle msgProperties) throws NaoConectouNaReceitaException {
        try {
            DataUtil.addParamToMap(request, paramMap);

            super.executeAction(request, paramMap);

            ReceitaBean receitaBean = new ReceitaBean(paramMap);
            ProxyBean proxyBean = new ProxyBean(paramMap);
            if (Verify.isEmpty(proxyBean.getHostProxy()) || Verify.isEmpty(proxyBean.getPortProxy())
                || Verify.isEmpty(proxyBean.getUserProxy())) {
                proxyBean = null;
            }

            //msgProperties = (ResourceBundle) paramMap.get("mensagensProperties");
            ConsPreviaBD consPreviaBD = new ConsPreviaBD(consPreviaBean, receitaBean, proxyBean, paramMap, factory,
                    msgProperties);
            consPreviaBD.consultData(contigencia);

            if ((consPreviaBean != null)
                && (consPreviaBean.getCodRetorno() != null)
                && ((Integer.parseInt(consPreviaBean.getCodRetorno()) <= 0) || ((Integer.parseInt(consPreviaBean
                        .getCodRetorno()) == COD_RET_CONS_SIMP_EMP_MEIO_PORTE) && DataUtil.isFromConsultaSimples(
                    request, paramMap)))) {
                setCodigo(consPreviaBean.getCodRetorno());
                // setMensagem(consPreviaBean.getNome());
                setMensagem(getMessageFromProperties(consPreviaBean.getCodRetorno()) == null
                        ? extraiRazaoSocialSimples(consPreviaBean.getCodRetorno(), consPreviaBean.getNome())
                        : getMessageFromProperties(consPreviaBean.getCodRetorno()));
                setConteudoRetorno(extraiRazaoSocialSimples(consPreviaBean.getCodRetorno(),
                    consPreviaBean.getConteudoRetorno()));
            } else {
                throw new TrataErros(consPreviaBean.getCodRetorno(), consPreviaBean.getNome(),
                        consPreviaBean.getConteudoRetorno());
            }
            log.debug("<ConsPreviaConsultCommand()");
        } catch (TrataErros e) {
            log.info("consPreviaBean.getCodRetorno()..: {}", consPreviaBean.getCodRetorno() + "fsdfs");
            log.info("consPreviaBean.getNome()........: {}", consPreviaBean.getNome());
            log.info("consPrevia.getConteudoRetorno().: {}", consPreviaBean.getConteudoRetorno());
            log.info("e.getCodigoErro()...............: {}", e.getCodigoErro());
            log.info("e.getMessage()..................: {}", e.getMensagemErro());
            setCodigo(e.getCodigoErro());
            // setMensagem(e.getMensagemErro());
            setMensagem(getMessageFromProperties(e.getCodigoErro()) == null
                    ? e.getMensagemErro()
                    : getMessageFromProperties(e.getCodigoErro()));
            setConteudoRetorno(e.getConteudoRetorno());
        } catch (NaoConectouNaReceitaException e) {
            throw e;
        } catch (Exception e) {
            log.error("N�o foi poss�vel efetuar a consulta.", e);
            addError("-> Pesquisa pr�via dos dados na SRF");
            addError("N�o foi poss�vel efetuar a consulta.");
            addError("Por favor, tente mais tarde !!!");
        }
    }

    // A Receita mudou o retorno da consulta simples, passou a ser no seguinte formato:
    // Nome da Pessoa#Razao Social#Mensagem indicando que a empresa faz parte do Simples Nacional
    // Este metodo extrai a Razao Social do retorno
    private String extraiRazaoSocialSimples(String codRetorno, String text) {
        try {
            if (Integer.parseInt(codRetorno) == COD_RET_CONS_SIMP_EMP_MEIO_PORTE) {
                log.info("Extrair razao social do retorno {}", text);
                if (StringUtils.isEmpty(text)) {
                    return "";
                }

                if (text.contains("#")) {
                    StringTokenizer tok = new StringTokenizer(text, "#");
                    int n = tok.countTokens();
                    if (n == 1) {
                        return StringUtils.trimToEmpty(tok.nextToken());
                    } else if (n >= 2) {
                        tok.nextToken(); // ignorar o primeiro token
                        return StringUtils.trimToEmpty(tok.nextToken());
                    }
                }

                return StringUtils.trimToEmpty(text);
            }
        } catch (Exception e) {
            // em caso de qualquer erro, retornar o texto original (precaucao pra quando a receita mudar de novo a resposta sem nos avisar)
            log.info("Nao foi possivel extrair a razao social do texto [{}]\nErro ({}): {}", text, e.getClass(),
                e.getMessage());
            return text;
        }

        return text;
    }

    public String getCodigo() {
        return this.codigo;
    }

    public String getMensagem() {
        return this.mensagem;
    }

    private void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    private void setMensagem(String mensagem) {
        this.mensagem = mensagem;
    }

    public String getConteudoRetorno() {
        return conteudoRetorno;
    }

    private void setConteudoRetorno(String conteudoRetorno) {
        this.conteudoRetorno = conteudoRetorno;
    }

    public String getMessageFromProperties(String chave) {
        if (msgProperties == null) {
            return null;
        }
        try {
            return msgProperties.getString(chave);
        } catch (MissingResourceException e) {
            log.info("chave (c�digo) {} n�o encontrada!", chave);
            return null;
        }
    }
}
