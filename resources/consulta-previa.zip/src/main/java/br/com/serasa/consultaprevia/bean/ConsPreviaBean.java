package br.com.serasa.consultaprevia.bean;

/**
 * Description of the Class
 * 
 * @author Bruno
 * @created 15 de Julho de 2003
 * @author tiziano
 * @alter 26 de janeiro de 2006
 */
public class ConsPreviaBean {
    public final static String TIPO_CERT_PF = "1";

    public final static String TIPO_CERT_PJ = "2";

    public final static String TIPO_CERT_SERVER = "3";

    /**
     * Description of the Field
     */

    //mensagem do serpro
    private String conteudoRetorno;

    protected String tpmsg;

    /**
     * Description of the Field
     */
    protected String tpCert;

    /**
     * Description of the Field
     */
    protected String nome;

    /**
     * Description of the Field
     */
    protected String cpf;

    /**
     * Description of the Field
     */
    protected String dtNasc;

    /**
     * Description of the Field numTitulo Utilizado apenas no tpCert = 1
     */
    protected String numTitulo;

    /**
     * Description of the Field cnpj Utilizado apenas no tpCert = 2 e 3
     */
    protected String cnpj;

    /**
     * Description of the Field
     */
    protected String codRetorno;

    /**
     * Description of the Field
     */
    protected String nextHelper;

    public void setTpMsg(String tpmsg) {
        this.tpmsg = tpmsg;
    }

    public String getTpMsg() {
        return this.tpmsg;
    }

    /**
     * Returns the cnpj.
     * 
     * @return String
     */
    public String getCnpj() {
        return cnpj;
    }

    /**
     * Returns the codRetorno.
     * 
     * @return String
     */
    public String getCodRetorno() {
        return codRetorno;
    }

    /**
     * Returns the cpf.
     * 
     * @return String
     */
    public String getCpf() {
        return cpf;
    }

    /**
     * Returns the dtNasc.
     * 
     * @return String
     */
    public String getDtNasc() {
        return dtNasc;
    }

    /**
     * Returns the nome.
     * 
     * @return String
     */
    public String getNome() {
        return nome;
    }

    /**
     * Returns the numTitulo.
     * 
     * @return String
     */
    public String getNumTitulo() {
        return numTitulo;
    }

    /**
     * Returns the tpCert.
     * 
     * @return String
     */
    public String getTpCert() {
        return tpCert;
    }

    /**
     * Sets the cnpj.
     * 
     * @param cnpj The cnpj to set
     */
    public void setCnpj(String cnpj) {
        this.cnpj = cnpj;
    }

    /**
     * Sets the codRetorno.
     * 
     * @param codRetorno The codRetorno to set
     */
    public void setCodRetorno(String codRetorno) {
        this.codRetorno = codRetorno;
    }

    /**
     * Sets the cpf.
     * 
     * @param cpf The cpf to set
     */
    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    /**
     * Sets the dtNasc.
     * 
     * @param dtNasc The dtNasc to set
     */
    public void setDtNasc(String dtNasc) {
        this.dtNasc = dtNasc;
    }

    /**
     * Sets the nome.
     * 
     * @param nome The nome to set
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * Sets the numTitulo.
     * 
     * @param numTitulo The numTitulo to set
     */
    public void setNumTitulo(String numTitulo) {
        this.numTitulo = numTitulo;
    }

    /**
     * Sets the tpCert.
     * 
     * @param tpCert The tpCert to set
     */
    public void setTpCert(String tpCert) {
        this.tpCert = tpCert;
    }

    /**
     * Returns the nextHelper.
     * 
     * @return String
     */
    public String getNextHelper() {
        return nextHelper;
    }

    /**
     * Sets the nextHelper.
     * 
     * @param nextHelper The nextHelper to set
     */
    public void setNextHelper(String nextHelper) {
        this.nextHelper = nextHelper;
    }

    public String getConteudoRetorno() {
        return conteudoRetorno;
    }

    public void setConteudoRetorno(String conteudoRetorno) {
        this.conteudoRetorno = conteudoRetorno;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();

        sb.append("CPF=").append(this.cpf);
        sb.append("; dt nasc=").append(this.dtNasc);

        if (!ConsPreviaBean.TIPO_CERT_PF.equalsIgnoreCase(this.tpCert)) {
            sb.append("; CNPJ=").append(this.cnpj);
        }

        return sb.toString();
    }
}
