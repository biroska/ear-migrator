package br.com.serasa.servlets.bean;

/**
 * Description of the Class
 * 
 * @author riko
 * @created 6 de Novembro de 2002
 */
public class ErrorBean {

    private String errors[];

    /**
     * Constructor for the ErrorBean object
     */
    public ErrorBean() {
        this(new String[0]);
    }

    /**
     * Constructor for the ErrorBean object
     * 
     * @param error Description of the Parameter
     */
    public ErrorBean(String error) {
        errors = new String[1];
        if (error != null) {
            errors[0] = new String(error);
        }
    }

    /**
     * Constructor for the ErrorBean object
     * 
     * @param errorList Description of the Parameter
     */
    public ErrorBean(String errorList[]) {
        if (errorList != null) {
            errors = new String[errorList.length];
            for (int i = 0; i < errorList.length; i++) {
                errors[i] = new String(errorList[i]);
            }
        }
    }

    /**
     * Gets the errors attribute of the ErrorBean object
     * 
     * @return The errors value
     */
    public String[] getErrors() {
        return errors == null ? new String[0] : errors;
    }
}
