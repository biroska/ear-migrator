package br.com.serasa.util;
import java.util.Map;
import java.util.StringTokenizer;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;

import br.com.serasa.tools.Verify;

public class DataUtil {

    /*
     * Validador de CGC de 14 digitos.
     * @param _cgc : CGC a ser validado.
     * @return boolean : true ou false.
     * <br> Otimizado em 04/04/2001 por CBG
     */
    private static boolean val_cgc14(String strCnpj) {
        if (!(strCnpj.length() == 14 && isNumber(strCnpj))) {
            return false;
        }
        if (strCnpj.equals("00000000000000") || strCnpj.equals("99999997999973") || strCnpj.equals("99999999000000")) {
            return false;
        }

        String mult = "543298765432";
        int dv = 0;
        int xcgc[] = new int[14];

        for (int j = 0; j < 14; j++) {
            xcgc[j] = Integer.parseInt(strCnpj.substring(j, j + 1));
        }

        for (int j = 0; j < 2; j++) {
            int soma = 0;
            int xmult[] = new int[12];

            for (int i = 0; i < 12; i++) {
                xmult[i] = Integer.parseInt(mult.substring(i, i + 1));
                soma = soma + (xcgc[i] * xmult[i]);
            }

            if (j == 1) {
                soma = soma + (2 * dv);
            }

            dv = (soma * 10) % 11;

            if (dv == 10) {
                dv = 0;
            }

            mult = "654329876543";

            if (dv != xcgc[12 + j]) {
                return false;
            }
        }
        return true;
    }

    /**
     * Validador de CGC de 15 digitos.
     * 
     * @param _cgc : CGC a ser validado.
     * @return boolean : true ou false. <br>
     *         Otimizado em 04/04/2001 por CBG
     **/
    private static boolean val_cgc15(String strCnpj) {
        if (strCnpj.equals("000000000000000")) {
            return false;
        }

        if (!(strCnpj.length() == 15 && isNumber(strCnpj))) {
            return false;
        }

        String mult = "6543298765432";
        int dv = 0;
        int xCgc[] = new int[15];

        for (int j = 0; j < 15; j++) {
            xCgc[j] = Integer.parseInt(strCnpj.substring(j, j + 1));
        }

        for (int j = 0; j < 2; j++) {
            int soma = 0;
            int xmult[] = new int[13];

            for (int i = 0; i < 13; i++) {
                xmult[i] = Integer.parseInt(mult.substring(i, i + 1));
                soma = soma + (xCgc[i] * xmult[i]);
            }

            if (j == 1) {
                soma = soma + (2 * dv);
            }

            dv = (soma * 10) % 11;

            if (dv == 10) {
                dv = 0;
            }

            mult = "76543298765432";

            if (dv != xCgc[13 + j]) {
                return false;
            }
        }
        return true;
    }

    /**
     * Redireciona para validadores de CGC especificos de 14 ou 15 digitos.
     * 
     * @param _cgc : CGC a ser validado.
     * @return boolean : true ou false.
     **/
    public static boolean isCnpjValid(String strCnpj) {
        switch (strCnpj.length()) {
            case 14:
                return val_cgc14(strCnpj);
            case 15:
                return val_cgc15(strCnpj);
            default:
                return false;
        }
    }

    public static int getInt(Object integer) {
        Number toInt = (Number) integer;
        if (toInt == null) {
            throw new NullPointerException("DataUtil.getInt(): integer null");
        }
        return toInt.intValue();
    }

    public static int parseInt(Object integer) {
        if (integer == null) {
            throw new NullPointerException("DataUtil.parseInt(): integer null");
        }
        String integerValue = integer.toString();
        return Integer.parseInt(integerValue);
    }

    public static String getStr(Object ob) {
        return ob == null ? null : ob.toString().trim();
    }

    /**
     * Recebe um string e d� um trim nele.
     * 
     * @param string a ser verificada
     * @return retorna strign com trim. Se for null, retorna string vazia.
     */
    public static String isNull(Object ob) {
        return ob == null ? "" : ob.toString().trim();
    }

    /**
     * Recebe um objeto, e faz um trim nele.
     * 
     * Utilizada pelo POST do CertRequest para o Notes.
     * 
     * @param ob string a ser verificada
     * @return Retorna a string com trim(). Se for null, retorna um espa�o em branco (por causa do Notes
     *         ->StringTokenizer)
     */
    public static String isNullSpace(Object ob) {
        return isNull(ob).equals("") ? " " : ob.toString().trim();
    }

    /**
     * A partir de uma string com v�rias linhas, devolve ela com uma s� linha.
     * 
     * @param toCut String a ser examinada. Pode ter uma ou mais linhas
     * @return Retorna a string em uma linha s�. Se toCut for null, devolve null.
     */
    public static String cutNewLine(String toCut) {
        if (toCut == null) {
            return null;
        }

        StringBuffer oneLine = new StringBuffer();
        StringTokenizer stoken = new StringTokenizer(toCut, "\r\n");
        while (stoken.hasMoreTokens()) {
            oneLine.append(stoken.nextToken());
        }
        return oneLine.toString();
    }

    /**
     * Obt�m o valor em String do primeiro elemento do array strArray Utilizado por exemplo para obter os valores do map
     * do HttpRequest, que trabalha com arrays.
     * 
     * @param strArray array de strings
     * @return Se strArray for null, retorna null. Sen�o retorna o valor da primeira string do array.
     */
    public static String getStrFromArray(Object strArray) {
        if (strArray == null) {
            return null;
        }
        try {
            return ((String[]) strArray)[0];
        } catch (ClassCastException cce) {
            return null;
        }
    }

    /**
     * Gets the empty attribute of the DataValidator class
     * 
     * @param toCheck Description of the Parameter
     * @return The empty value
     */
    public static boolean isEmpty(Object toCheck) {
        if (toCheck == null) {
            return true;
        }
        if (toCheck instanceof String) {
            return ((String) toCheck).trim().equals("");
        }
        return false;
    }

    /**
     * Gets the number attribute of the DataValidator class
     * 
     * @param toCheck Description of the Parameter
     * @return The number value
     */
    public static boolean isNumber(String toCheck) {
        if (toCheck == null) {
            return false;
        }
        try {
            Long.parseLong(toCheck.trim());
        } catch (NumberFormatException nfe) {
            return false;
        }
        return true;
    }

    public static String insertZeros(String str, int length) throws IllegalArgumentException {
        if (str == null) {
            throw new NullPointerException("str is NULL.");
        }
        if (str.length() > length) {
            throw new IllegalArgumentException("Valor " + str + " deve ter no m�ximo " + length + " caracteres.");
        }
        int offset = length - str.length();
        StringBuilder ret = new StringBuilder();
        for (int i = 0; i < offset; i++) {
            ret.append("0");
        }
        ret.append(str);
        return ret.toString();
    }

    public static String checaEspeciais(String str) {
        String strRetorna = new String(str);

        String informado = "�����������������������������������������������������@!?#$%<>{}_?&\\[]|��,;=*+�������׿������������ߵ�ޯ�������������`^�~'\"";
        String convertido = "aeiouaeiouaeiouaeiouaocAEIOUAEIOUAEIOUAEIOUAOCaAnNyyY                                                                       ";

        char chInformado[] = informado.toCharArray();
        char chConvertido[] = convertido.toCharArray();

        for (int i = 0; i < informado.length() - 1; i++) {
            strRetorna = strRetorna.replace(chInformado[i], chConvertido[i]);
        }

        return strRetorna.trim().toUpperCase().replaceAll("\\s+", " ");
    }

    /**
     * Gets the cpfValid attribute of the DataValidator class
     * 
     * @param cpf Description of the Parameter
     * @return The cpfValid value
     */
    public static boolean isCpfValid(String cpf) {

        if (!(cpf.length() == 11)) {
            return false;
        }

        if (cpf.equals("00000000000") || cpf.equals("11111111111") || cpf.equals("22222222222")
            || cpf.equals("33333333333") || cpf.equals("44444444444") || cpf.equals("55555555555")
            || cpf.equals("66666666666") || cpf.equals("77777777777") || cpf.equals("88888888888")
            || cpf.equals("99999999999")) {
            return false;
        }

        int num[] = new int[11];

        // d�gitos verificadores
        int dv1;

        // d�gitos verificadores
        int dv2;

        // auxiliares no c�lculo
        int soma;

        // auxiliares no c�lculo
        int resto;

        // guarda os n�meros em um vetor de inteiros para c�lculos posteriores
        for (int i = 0; i < 11; i++) {
            num[i] = Integer.parseInt(cpf.substring(i, i + 1));
        }

        // calcula o primeiro d�gito verificador

        soma = 10 * num[0] + 9 * num[1] + 8 * num[2] + 7 * num[3] + 6 * num[4] + 5 * num[5] + 4 * num[6] + 3 * num[7]
               + 2 * num[8];

        resto = soma % 11;
        dv1 = 11 - resto;

        if (dv1 > 9) {
            dv1 = 0;
        }

        // verifica se o primeiro d�gito verificador est� correto
        if (dv1 == num[9]) {
            // calcula o segundo d�gito verificador

            soma = 11 * num[0] + 10 * num[1] + 9 * num[2] + 8 * num[3] + 7 * num[4] + 6 * num[5] + 5 * num[6] + 4
                   * num[7] + 3 * num[8] + 2 * num[9];

            resto = soma % 11;
            dv2 = 11 - resto;

            if (dv2 > 9) {
                dv2 = 0;
            }

            if (dv2 == num[10]) {
                return true;
            }

            return false;
        }

        return false;
    }

    public static String retiraAspas(String str) {
        String ret = "";
        if (str != null) {
            ret = str.replaceAll("[\'\"]", "");
        }
        return ret;
    }

    public static String aceitaSomenteLetrasNumeros(String str) {

        String informado = checaEspeciais(str);

        final String validos = "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZ";

        char chValidos[] = validos.toCharArray();
        char chInformado[] = informado.toCharArray();
        StringBuilder strRetorna = new StringBuilder();

        for (int i = 0; i < informado.length(); i++) {
            for (int j = 0; j < validos.length(); j++) {
                if (chInformado[i] != chValidos[j]) {
                    strRetorna.append("");
                } else {
                    strRetorna.append(chInformado[i]);
                }
            }
        }

        return strRetorna.toString().trim().toUpperCase();
    }

    public static boolean isEmailValid(String toCheck) {
        final String response = toCheck.toUpperCase().trim();

        if (isEmpty(toCheck)) {
            return false;
        }

        // caso n�o encontre o caracter "@" ou ".", retorna falso
        //TODO retirar a obrigatoriedade do ".", por causa do email no ambiente de homologa��o
        //if (response.indexOf("@",0) == -1 || response.indexOf(".",0) == -1) {
        if (response.indexOf("@", 0) == -1) {
            return false;
        }

        // caso n�o encontre algum dos caracteres validos, retorna falso
        final String validos = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ@-._";
        char chValidos[] = validos.toCharArray();
        char chInformados[] = response.toCharArray();
        boolean pesquisaCaracter = true;

        for (int i = 0; i < response.length(); i++) {
            pesquisaCaracter = true;
            for (int j = 0; j < validos.length() && pesquisaCaracter; j++) {
                if (chInformados[i] == chValidos[j]) {
                    pesquisaCaracter = false;
                }
            }
            // caso n�o encontrou o caracter na lista valida, retorna falso
            if (pesquisaCaracter) {
                return false;
            }
        }

        // caso encontre um "espa�o", retorna falso
        if (response.indexOf(" ", 0) != -1) {
            return false;
        }

        return true;
    }
    
    public static boolean isFromConsultaSimples(HttpServletRequest request) {
    	boolean retVal = false;
    	String consSimplesParam = "";
    	
    	consSimplesParam = request.getParameter("provConsSimples");
    	if ((consSimplesParam != null) && "1".equals(consSimplesParam)) {
    	  	retVal = true;
    	} 
    	
    	return retVal;
    }
    
    public static boolean isFromConsultaSimples(Map<String, String> paramMap) {
    	boolean retVal = false;
    	
    	if ((paramMap != null) && "1".equals((String)paramMap.get("provConsSimples"))) {
    	  	retVal = true;
    	} 
    	
    	return retVal;
    }
    
    public static boolean isFromConsultaSimples(HttpServletRequest request, Map<String, String> paramMap) {
    	return (isFromConsultaSimples(request) || isFromConsultaSimples(paramMap));
    }
    
    public static void addParamToMap(HttpServletRequest request, Map<String, String> paramMap) {
    	if (request.getParameter("radioVerificaSimples") != null) {  // prov�m da index.jsp (pagina de teste)
            if ("1".equals(request.getParameter("radioVerificaSimples").toString())) {
                paramMap.put("provConsSimples", "1"); // proveni�ncia consulta simples.	
            } else if ("0".equals(request.getParameter("radioVerificaSimples").toString())){
            	paramMap.put("provConsSimples", "0"); // n�o prov�m da consulta simples.	
            }
    	} else { // prov�m da outra aplica��o.
    		if (isFromConsultaSimples(request)) {
    			paramMap.put("provConsSimples", "1"); // proveni�ncia consulta simples.	
    		} else {
    			paramMap.put("provConsSimples", "0"); // n�o prov�m da consulta simples.	
    		}
    	}    	
    }
    
    public static String formatarTextoConsultaSimples(String texto) {
        String ret = "";
        if (!Verify.isEmpty(texto)) {
            String[] arrTexto = texto.split("#");
            if (arrTexto.length == 3) {
                ret = StringUtils.trim(arrTexto[1]);
            } else {
            	ret = texto;
            }
        }
        return ret;
    }
}
