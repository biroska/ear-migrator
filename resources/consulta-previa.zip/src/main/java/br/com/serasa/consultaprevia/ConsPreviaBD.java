package br.com.serasa.consultaprevia;

import java.io.IOException;
import java.io.InputStream;
import java.security.InvalidKeyException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.cert.CertificateException;
import java.security.spec.InvalidKeySpecException;
import java.sql.Blob;
import java.sql.SQLException;
import java.util.Map;
import java.util.MissingResourceException;
import java.util.ResourceBundle;
import java.util.regex.Pattern;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.net.ssl.SSLSocketFactory;

import org.apache.commons.io.IOUtils;
import org.owasp.esapi.CustomLogger;
import org.owasp.esapi.CustomLoggerFactory;

import br.com.serasa.bd.FunctionQuery;
import br.com.serasa.bd.QueryException;
import br.com.serasa.bd.ResultQuery;
import br.com.serasa.bd.StatementQuery;
import br.com.serasa.bean.bdconnection.BDConnectionBean;
import br.com.serasa.consultaprevia.bean.ConsPreviaBean;
import br.com.serasa.consultaprevia.bean.KeyStoreBean;
import br.com.serasa.consultaprevia.bean.ProxyBean;
import br.com.serasa.consultaprevia.bean.ReceitaBean;
import br.com.serasa.exception.NaoConectouNaReceitaException;
import br.com.serasa.exception.TrataErros;
import br.com.serasa.socket.SSLSerasaSocket;
import br.com.serasa.tools.Verify;
import br.com.serasa.util.DataUtil;
import br.com.serasa.util.PublicConstantUtil;
import br.com.serasa.util.StringCipher;

/**
 * Consulta no BD os dados da SRF, prenchendo os dados nos JavaBeans para ConsPreviaBean.
 * 
 * @author Bruno
 * @created 18 de Julho de 2003
 */
public class ConsPreviaBD {

    public SSLSocketFactory getFactory() {
        return factory;
    }

    public void setFactory(SSLSocketFactory factory) {
        this.factory = factory;
    }

    public static final String VALOR_RETORNO_DADO_SEM_VALIDACAO = PublicConstantUtil.CICLOBD_VALOR_RETORNO_DADO_SEM_VALIDACAO;

    public static final String VALOR_RETORNO_CONS_SIMPLES_DADO_SEM_VALIDACAO = PublicConstantUtil.CICLOBD_VALOR_RETORNO_CONS_SIMPLES_DADO_SEM_VALIDACAO;

    public static final String CODIGO_RETORNO_CONS_SIMPLES_PORTE_DA_EMPRESA = "60";

    public static final String CODIGO_RETORNO_CPF_CNPJ_SUCESSO = "00";

    private static final String SPC_CONSPREVIA_MIN = "SPC_CONSPREVIA_MIN";

    private CustomLogger log = CustomLoggerFactory.getLogger(this.getClass().getName());

    private ResourceBundle msgProperties;

    private SSLSerasaSocket sslSerasaSocket;

    private String codigoRetornoSRF;

    private String textoRetornoSRF;

    private StringBuffer paramConsPrevia;

    // mensagem do Serpro
    private String conteudoRetorno;

    private SSLSocketFactory factory;

    /**
     * Consulta os dados no layout de pesquisa P.Fisica.
     * 
     * @param tpCert Tipo do Certificado
     * @param consPreviaPFBean Description of the Parameter
     */
    private ConsPreviaBean consPreviaBean;

    private ReceitaBean receitaBean;

    private ProxyBean proxyBean;

    private Map<String, String> paramMap;

    private boolean provConsSimples = false;

    public ConsPreviaBD(ConsPreviaBean consPreviaBean, ReceitaBean receitaBean, ProxyBean proxyBean,
            Map<String, String> paramMap, SSLSocketFactory factory, ResourceBundle msgProperties) {
        log.debug(">ConsPreviaBD()");
        setConsPreviaBean(consPreviaBean);
        setReceitaBean(receitaBean);
        setProxyBean(proxyBean);
        setParamMap(paramMap);
        setMsgProperties(msgProperties);
        setFactory(factory);
        log.debug("<ConsPreviaBD()");
    }

    public ConsPreviaBD(ConsPreviaBean consPreviaBean) {
        log.debug(">ConsPreviaBD()");
        setConsPreviaBean(consPreviaBean);
        log.debug("<ConsPreviaBD()");
    }

    private void setConsPreviaBean(ConsPreviaBean consPreviaBean) {
        this.consPreviaBean = consPreviaBean;
    }

    private ConsPreviaBean getConsPreviaBean() {
        return this.consPreviaBean;
    }

    private void setReceitaBean(ReceitaBean receitaBean) {
        this.receitaBean = receitaBean;
    }

    private ReceitaBean getReceitaBean() {
        return this.receitaBean;
    }

    private void setProxyBean(ProxyBean proxyBean) {
        this.proxyBean = proxyBean;
    }

    private ProxyBean getProxyBean() {
        return this.proxyBean;
    }

    public boolean consultData() throws TrataErros, NaoConectouNaReceitaException {
        return consultData(true);
    }

    public boolean consultData(boolean contigencia) throws TrataErros, NaoConectouNaReceitaException {
        provConsSimples = DataUtil.isFromConsultaSimples(paramMap);

        if (getConsPreviaBean() == null) {
            // throw new TrataErros("-4", "ConsPreviaBean null.");
            throw new TrataErros("-4", "ConsPreviaBean null.", "");
        }

        for (int i = 0; i < this.receitaBean.urlsQty(); i++) {
            try {
                this.receitaBean.setCurrentIndex(i);
                log.info("Tentando consulta em {} ({})", receitaBean.getCurrentUrlReceita(),
                    receitaBean.getCurrentIpReceita());

                paramConsPrevia = new StringBuffer(this.receitaBean.getCurrentUrlReceita());
                String tipoCert = consPreviaBean.getTpCert();
                log.debug("tipoCert= {}", tipoCert);
                if (Verify.isControladorDeDominio(tipoCert))
                    tipoCert = "2"; // Receita nao aceita tipo 7, mudar para 3 (servidor) = 11/12/2007 - mudar para 2 (PJ), servico INFO-CONV: respons�vel pelo certificado digital ser tamb�m o respons�vel pelo CNPJ da empresa conforme o cadastro na base da Receita Federal
                paramConsPrevia.append("TipoCert=" + tipoCert);
                paramConsPrevia.append("&CPF=" + consPreviaBean.getCpf());
                log.info("Parametros da consulta previa: {}", paramConsPrevia.toString());

                if (ConsPreviaBean.TIPO_CERT_PF.equalsIgnoreCase(consPreviaBean.getTpCert())) {
                    paramConsPrevia.append("&DataNasc=" + consPreviaBean.getDtNasc());
                    // Se provier da Consulta simples, CNPJ tem que ser enviado mesmo que o tipo certificado for = 1
                    if (provConsSimples) {
                        paramConsPrevia.append("&CNPJ=" + consPreviaBean.getCnpj());
                    }

                    // Trevisan - Alteracao solicitada em 14/02/2005 retirando a
                    // validacao do Titulo de Eleitor da Consulta Previa
                    // paramConsPrevia.append("&TituloEleitor=" +
                    // consPreviaBean.getNumTitulo());

                } else {
                    paramConsPrevia.append("&CNPJ=" + consPreviaBean.getCnpj());
                    paramConsPrevia.append("&DataNasc=" + consPreviaBean.getDtNasc());
                }

                if (contigencia) {
                    executePesquisa(paramConsPrevia.toString());
                } else {
                    executePesquisa(paramConsPrevia.toString(), contigencia);
                }

                // Codigo de retorno 90, 91, 92, 93, 94, 95, 96, 97, 98
                // Servi�o indispon�vel
                if (codigoRetornoSRF != null && Pattern.compile("^9[0-8]").matcher(codigoRetornoSRF).find()) {
                    throw new TrataErros(codigoRetornoSRF, getMessageFromProperties(codigoRetornoSRF) == null
                            ? textoRetornoSRF
                            : getMessageFromProperties(codigoRetornoSRF), conteudoRetorno);
                }

                // se foi possivel obter os 2 digitos de status
                // entao consulta foi efetuada
                if (codigoRetornoSRF != null && Pattern.compile("^[0-9][0-9]").matcher(codigoRetornoSRF).find()) {
                    break;
                }
            } catch (TrataErros e) {
                if (i == receitaBean.urlsQty() - 1) { // se ja esta na ultima url
                    throw e;
                }
            }
            // if ("00".equals(codigoRetornoSRF)) // sucesso, nao precisa consultar as outras urls
            // break;
        }

        consPreviaBean.setNome(textoRetornoSRF);
        consPreviaBean.setCodRetorno(codigoRetornoSRF);
        consPreviaBean.setConteudoRetorno(conteudoRetorno);// msg do Serpro
        return true;
    }

    /**
     * Executar a pesquisa dos dados na SRF
     * 
     * @param paramUrl URL formatada com todos os par�metros
     * @param connectionBean TODO
     * @throws NaoConectouNaReceitaException
     */
    private boolean executePesquisa(String paramUrl) throws TrataErros, NaoConectouNaReceitaException {
        return executePesquisa(paramUrl, true);
    }

    private boolean executePesquisa(String paramUrl, boolean contigencia) throws TrataErros,
            NaoConectouNaReceitaException {
        log.debug(">executePesquisa()");
        /*
         * sslSerasaSocket = new SSLSerasaSocket(getProxyBean(), getReceitaBean(), paramUrl, (String) paramMap.get("keystore_receita"), (String) paramMap.get("keystore_password"));
         */

        sslSerasaSocket = new SSLSerasaSocket(getProxyBean(), getReceitaBean(), paramUrl, null, null, factory);

        final int timeout = Integer.parseInt((String) paramMap.get("consprevia_timeout"));
        sslSerasaSocket.setTimeout(timeout);

        boolean httpsStatus = sslSerasaSocket.executeConsultaHttps();
        boolean servicoIndisponivel = false;
        if (httpsStatus) {
            log.info("Verificando retorno");
            String conteudoRetorno = sslSerasaSocket.getConteudoRetorno();
            log.info("retorno= {}", conteudoRetorno);
            try {
                int retorno = Integer.parseInt(conteudoRetorno.substring(0, 2));
                switch (retorno) {
                    case 90:
                    case 91:
                    case 92:
                    case 93:
                    case 94:
                    case 95:
                    case 96:
                    case 97:
                    case 98:
                        log.info("indisponivel!!!!!!!!!");
                        servicoIndisponivel = true;
                        break;
                }
            } catch (Exception e) {
                servicoIndisponivel = true;
            }
        } else {
            servicoIndisponivel = true;
        }

        if (servicoIndisponivel && contigencia) {
            // riko 02/01/2009 - alterado para corre��o tempor�ria CD expirado da Serasa:
            // Caso d� erro na receita, tenta-se consultar a base local pelo CPF/CNPJ, devolvendo o nome/raz�o social para os clientes da ConsultaPrevia Serasa (req, apr, renova��o, e-commerce, promo��o)
            // Caso n�o se ache o CPF/CNPJ na base DBCICLO, devolver msg padr�o: "Sendo validado pela Receita";
            // Nesse caso a requisi��o ir� mostrar um aviso ao cliente dizendo que no AVP ser� validado corretamente mas pode prosseguir sem problemas
            // veja http://wiki.cddesenv.intranet/Wiki.jsp?page=ControleProjetos_Ciclo_ConsultaPrevia_10_72
            log.warn("Problemas com servico Receita.");

            if (provConsSimples) {
                codigoRetornoSRF = CODIGO_RETORNO_CONS_SIMPLES_PORTE_DA_EMPRESA;
                log.debug("Servico Receita indisponivel - Retornar default dados sem validacao");
                textoRetornoSRF = VALOR_RETORNO_CONS_SIMPLES_DADO_SEM_VALIDACAO;
                setConteudoRetorno(VALOR_RETORNO_CONS_SIMPLES_DADO_SEM_VALIDACAO);
            } else {
                throw new NaoConectouNaReceitaException(consPreviaBean);
            }
            //            } catch (QueryException e) {
            //                log.error("Erro na consulta BD", e);
            //                throw new TrataErros(
            //                        "-5",
            //                        "<![CDATA[Servi�o de valida��o dos dados do titular do Certificado Digital provido pela  Receita Federal Brasileira esta indispon�vel no momento. Em caso de d�vida entre em contato com a SRF/RFB atraves do telefone 0800 728 2323]]>",
            //                        "Servico indisponivel");
            //            }

            log.debug("<executePesquisa()");
            return true;
        }

        String conteudoRetorno = sslSerasaSocket.getConteudoRetorno();
        log.info("ConsultaPrevia.conteudoRetorno= {}", conteudoRetorno);

        if (conteudoRetorno == null || "".equals(conteudoRetorno.trim())) {
            // throw new TrataErros("-5", "Conteudo do retorno vazio.");
            throw new TrataErros(
                    "-5",
                    "<![CDATA[Servi�o de valida��o dos dados do titular do Certificado Digital provido pela  Receita Federal Brasileira esta indispon�vel no momento. Em caso de d�vida entre em contato com a SRF/RFB atraves do telefone 0800 728 2323]]>",
                    "Servico indisponivel");
        }
        // boolean sucesso = conteudoRetorno.indexOf("<html>") == -1;
        boolean sucesso = Pattern.compile("^[0-9][0-9]").matcher(conteudoRetorno).find();
        if (sucesso) {
            // log.info("sucesso da consulta = " + sucesso);
            int tamanhoTxt = conteudoRetorno.trim().length();
            // teste tiziano
            log.info("Retorno da receita: {}", conteudoRetorno.trim());
            // fim teste tiziano

            // recuperar as 2 primeiras posi��es do String de retorno
            codigoRetornoSRF = conteudoRetorno.substring(0, 2);

            // recuperar da posi��o 3 at� o final do String de retorno
            // if ("00".equals(codigoRetornoSRF))
            textoRetornoSRF = conteudoRetorno.substring(2, tamanhoTxt);
            log.debug("Conteudo retorno={}", conteudoRetorno);
            // else textoRetornoSRF = ErrorsMap.getMsgError(codigoRetornoSRF);

            // Adiciona mensagem do Serpro
            setConteudoRetorno(conteudoRetorno);

            log.debug("<executePesquisa()");
            return true;
        }
        // throw new TrataErros("-5", "Nao foi possivel consultar os dados. Tente novamente.");
        // situacao em que nao houve erro, mas a msg nao veio no formato correto
        throw new TrataErros(
                "-5",
                "<![CDATA[Servi�o de valida��o dos dados do titular do Certificado Digital provido pela  Receita Federal Brasileira esta indispon�vel no momento. Em caso de d�vida entre em contato com a SRF/RFB atraves do telefone 0800 728 2323]]>",
                "Servico indisponivel");
    }

    public String consultaDadosCiclo(BDConnectionBean connectionBean) throws QueryException {
        log.debug(">consultaDadosCiclo()");

        String ret = VALOR_RETORNO_DADO_SEM_VALIDACAO;

        if (ConsPreviaBean.TIPO_CERT_PF.equalsIgnoreCase(consPreviaBean.getTpCert())) {
            log.debug("consultando dados de PF, cpf= {} dtNasc= {}", consPreviaBean.getCpf(),
                consPreviaBean.getDtNasc());

            // consultar pelo CPF, trazendo nome
            FunctionQuery query = FunctionQuery.getInstance(connectionBean, "SPC_RECUPERA_RESPONSAVEL");
            query.addParam(consPreviaBean.getCpf());
            query.addParam("1");

            ResultQuery result = StatementQuery.executeConsultQuery(connectionBean, query);
            if (result.next()) {
                ret = result.getString("cn_part");
            }
        } else {
            log.debug("consultando dados de PJ, cpf= {}, cnpj= {} dtNasc= {}", consPreviaBean.getCpf(),
                consPreviaBean.getCnpj(), consPreviaBean.getDtNasc());

            // consultar pelo CNPJ, trazendo razao social

            // consultar pelo CPF, trazendo nome
            FunctionQuery query = FunctionQuery.getInstance(connectionBean, "SPC_RECUPERA_RESPONSAVEL");
            query.addParam(consPreviaBean.getCnpj());
            query.addParam("2");

            ResultQuery result = StatementQuery.executeConsultQuery(connectionBean, query);
            if (result.next()) {
                ret = result.getString("cn_part");
            }
        }

        log.debug("<consultaDadosCiclo(): ret= {}", ret);
        return ret;
    }

    public KeyStoreBean getKeyStoreFromBD(BDConnectionBean connectionBean) throws QueryException, KeyStoreException,
            NoSuchAlgorithmException, CertificateException, IOException, InvalidKeyException,
            IllegalBlockSizeException, BadPaddingException, NoSuchProviderException, NoSuchPaddingException {
        log.trace("> getKeyStoreFromBD()");

        KeyStore ks = KeyStore.getInstance("JKS");
        KeyStoreBean keyStoreBean = new KeyStoreBean();
        InputStream is = null;

        try {
            FunctionQuery query = FunctionQuery.getInstance(connectionBean, SPC_CONSPREVIA_MIN);

            ResultQuery rs = StatementQuery.executeConsultQuery(connectionBean, query);
            if (rs.next()) {
                StringCipher stringCipher = new StringCipher();
                Blob blob = (Blob) rs.get("file_content");
                String senhaCriptografada = rs.getString("file_password");
                String senhaDecriptada = stringCipher.decrypt(senhaCriptografada);
                is = blob.getBinaryStream();
                ks.load(is, senhaDecriptada.toCharArray());
                is.close();

                keyStoreBean.setKeystore(ks);
                keyStoreBean.setPassword(senhaDecriptada);
            }
        } catch (SQLException e) {
            throw new QueryException("Erro ao ler keystore! ", e);
        } catch (InvalidKeySpecException e) {
            throw new QueryException("Chave de criptografia invalida! ", e);
        } finally {
            IOUtils.closeQuietly(is);
        }
        return keyStoreBean;
    }

    public Map<String, String> getParamMap() {
        return paramMap;
    }

    public void setParamMap(Map<String, String> paramMap) {
        this.paramMap = paramMap;
    }

    public String getConteudoRetorno() {
        return conteudoRetorno;
    }

    public void setConteudoRetorno(String conteudoRetorno) {
        this.conteudoRetorno = conteudoRetorno;
    }

    public ResourceBundle getMsgProperties() {
        return msgProperties;
    }

    public void setMsgProperties(ResourceBundle msgProperties) {
        this.msgProperties = msgProperties;
    }

    public String getMessageFromProperties(String chave) {
        if (msgProperties == null) {
            return null;
        }
        try {
            return msgProperties.getString(chave);
        } catch (MissingResourceException e) {
            log.info("chave {} n�o encontrada!", chave);
            return null;
        }
    }
}
