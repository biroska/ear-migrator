package br.com.serasa.consultaprevia;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import org.owasp.esapi.CustomLogger;
import org.owasp.esapi.CustomLoggerFactory;

/**
 * Description of the Class
 * 
 * @author Bruno
 * @created 06 de Fevereiro de 2004
 */
public class ConsPreviaTestCommand extends ConsPreviaValidateCommand {

    private CustomLogger log = CustomLoggerFactory.getLogger(this.getClass().getName());

    /**
     * Description of the Method
     * 
     * @return Description of the Return Value
     */
    @Override
    public boolean executeAction(HttpServletRequest request, Map<String, String> paramMap) throws Exception {
        super.executeAction(request, paramMap);

        if (noErrors()) {
            consultaSRF(request.getParameter("tipoFormulario"));
        }
        
        return noErrors();
    }

    /**
     * Executa a consulta dos Dados na SRF no formato TESTES.
     * 
     * Caso ocorra algum erro, loga-se a exception e continua a execu��o normalmente.
     */
    public void consultaSRF(String tipoFormulario) {
        final boolean tipoPF = "1".equals(tipoFormulario);
        log.info("CPF= {}", consPreviaBean.getCpf());
        log.info("cnpj= {}", consPreviaBean.getCnpj());
        if (tipoPF && "11122233396".equalsIgnoreCase(consPreviaBean.getCpf())) {
            consPreviaBean.setCodRetorno("00");
            consPreviaBean.setNome("NOME HOMOLOGACAO PARA CONSULTA PREVIA");
        } else if (!tipoPF && "69101830000101".equals(consPreviaBean.getCnpj())) {
            consPreviaBean.setCodRetorno("00");
            consPreviaBean.setNome("RAZAO SOCIAL HOMOLOGACAO CONSULTA PREVIA");
        } else if ("22233344405".equalsIgnoreCase(consPreviaBean.getCpf())) {
            consPreviaBean.setCodRetorno("99");
            consPreviaBean.setNome("Documento n�o encontrado !!!");
            //
            addError("-> Pesquisa pr�via dos dados na SRF");
            addError("C�digo de retorno: " + consPreviaBean.getCodRetorno());
            addError("Mensagem de retorno: " + consPreviaBean.getNome());
        } else {
            addError("-> Pesquisa pr�via dos dados na SRF");
            addError("N�o foi poss�vel efetuar a consulta.");
            addError("Por favor, tente mais tarde !!!");
        }
    }
}
