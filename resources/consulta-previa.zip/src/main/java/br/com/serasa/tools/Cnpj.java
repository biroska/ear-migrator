/*
 * Created on 20/02/2004
 */
package br.com.serasa.tools;

import java.util.ArrayList;
import java.util.List;

/**
 * @author dadario
 * 
 */
public class Cnpj {

    private static List<String> CNPJ_INVALIDOS = new ArrayList<String>();

    static {
        CNPJ_INVALIDOS.add("00000000000000");
        CNPJ_INVALIDOS.add("99999997999973");
        CNPJ_INVALIDOS.add("99999999000000");
        CNPJ_INVALIDOS.add("000000000000000");
    }

    public static boolean isValid(String cnpj) {

        if (Verify.isEmpty(cnpj) || !Verify.isNumber(cnpj) || CNPJ_INVALIDOS.contains(cnpj)) {
            return false;
        }

        switch (cnpj.length()) {
            case 14:
                return verifica14(cnpj);
            case 15:
                return valida15(cnpj);
            default:
                return false;
        }
    }

    /**
     * Validador de CGC de 14 digitos.
     * 
     * @param _cgc : CGC a ser validado.
     * @return boolean : true ou false. <br>
     *         Otimizado em 04/04/2001 por CBG
     **/
    private static boolean verifica14(String cnpj) {

        String mult = "543298765432";
        int dv = 0;
        int xcgc[] = new int[14];

        for (int j = 0; j < 14; j++) {
            xcgc[j] = Integer.parseInt(cnpj.substring(j, j + 1));
        }

        for (int j = 0; j < 2; j++) {
            int soma = 0;
            int xmult[] = new int[12];

            for (int i = 0; i < 12; i++) {
                xmult[i] = Integer.parseInt(mult.substring(i, i + 1));
                soma = soma + (xcgc[i] * xmult[i]);
            }

            if (j == 1) {
                soma = soma + (2 * dv);
            }

            dv = (soma * 10) % 11;

            if (dv == 10) {
                dv = 0;
            }

            mult = "654329876543";

            if (dv != xcgc[12 + j]) {
                return false;
            }
        }
        return true;
    }

    /**
     * Validador de CGC de 15 digitos.
     * 
     * @param _cgc : CGC a ser validado.
     * @return boolean : true ou false. <br>
     *         Otimizado em 04/04/2001 por CBG
     **/
    private static boolean valida15(String strCnpj) {

        String mult = "6543298765432";
        int dv = 0;
        int xCgc[] = new int[15];

        for (int j = 0; j < 15; j++) {
            xCgc[j] = Integer.parseInt(strCnpj.substring(j, j + 1));
        }

        for (int j = 0; j < 2; j++) {
            int soma = 0;
            int xmult[] = new int[13];

            for (int i = 0; i < 13; i++) {
                xmult[i] = Integer.parseInt(mult.substring(i, i + 1));
                soma = soma + (xCgc[i] * xmult[i]);
            }

            if (j == 1) {
                soma = soma + (2 * dv);
            }

            dv = (soma * 10) % 11;

            if (dv == 10) {
                dv = 0;
            }

            mult = "76543298765432";

            if (dv != xCgc[13 + j]) {
                return false;
            }
        }
        return true;
    }
}
