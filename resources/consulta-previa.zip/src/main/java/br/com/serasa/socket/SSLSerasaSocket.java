package br.com.serasa.socket;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.LineNumberReader;
import java.io.PrintWriter;
import java.net.Authenticator;
import java.net.URL;
import java.net.URLConnection;
import java.util.Properties;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;

import org.owasp.esapi.CustomLogger;
import org.owasp.esapi.CustomLoggerFactory;

import br.com.serasa.consultaprevia.bean.ProxyBean;
import br.com.serasa.consultaprevia.bean.ReceitaBean;

public class SSLSerasaSocket {

    private static final int DEFAULT_TIMEOUT = 10 * 1000;

    private String conteudoRetorno;

    private String descricao_erro;

    private String passphrase;
    
    private CustomLogger log = CustomLoggerFactory.getLogger(this.getClass().getName());

    private String path;

    private ProxyBean proxyBean;

    private ReceitaBean receitaBean;

    private Properties systemProperties;

    private String truststore;

    private SSLSocketFactory factory;

    private int timeout;

    public SSLSocketFactory getFactory() {
        return factory;
    }

    public void setFactory(SSLSocketFactory factory) {
        this.factory = factory;
    }

    public SSLSerasaSocket(ProxyBean proxyBean, ReceitaBean receitaBean, String path, String truststore, String pass,
            SSLSocketFactory factory) {

        try {
            try {
                this.setProxyBean(proxyBean);
                this.setReceitaBean(receitaBean);
                this.setPath(path);
                this.setConteudoRetorno("");
                this.setFactory(factory);

                if (!this.verificaParametros()) {
                    log.info("USO: new SSLSerasaSocket(String host, String port, String path, String truststore, String passphrase");
                }
            } catch (IllegalArgumentException e) {
                log.info("USO: new SSLSerasaSocket(String host, String port, String path, String truststore, String passphrase");
                this.descricao_erro = "Exce��o no carregamento dos parametros de entrada";
            }
        } catch (Exception e) {
            log.error("Exce��o na classe: ", e);
            this.descricao_erro = "Exce��o na classe: " + e.getMessage();
        }
    }

    private boolean closeConnections(LineNumberReader in, PrintWriter out, SSLSocket socket) {
        try {
            if (in != null) {
                in.close();
            }
            if (out != null) {
                out.close();
            }
            if (socket != null) {
                socket.close();
            }
            return true;
        } catch (IOException e1) {
            this.descricao_erro = "Falha ao Conectar: " + e1.toString();
            log.error(this.descricao_erro, e1);
            return false;
        }
    }

    private void finalizaConexaoProxy() {
        log.info("Entrou=================finalizaConexaoProxy");
        systemProperties.remove("http.proxyHost");
        systemProperties.remove("http.proxyPort");
        systemProperties.remove("https.proxyHost");
        systemProperties.remove("https.proxyPort");
        log.info("Saiu=================finalizaConexaoProxy");
    }

    public String getConteudoRetorno() {
        return this.conteudoRetorno;
    }

    public String getDescricaoErro() {
        return this.descricao_erro;
    }

    public String getPassphrase() {
        return this.passphrase;
    }

    public String getPath() {
        return this.path;
    }

    public ProxyBean getProxyBean() {
        return this.proxyBean;
    }

    public ReceitaBean getReceitaBean() {
        return this.receitaBean;
    }

    public String getTrustStore() {
        return this.truststore;
    }

    private void iniciaConexaoProxy() {
        // TODO retirar depois! Apenas teste via proxy
        log.info("Entrou=================iniciaConexaoProxy()");
        Authenticator.setDefault(new br.com.serasa.socket.ProxyAuthenticator(proxyBean.getUserProxy(), proxyBean
                .getPasswordProxy()));

        systemProperties.setProperty("http.proxyHost", proxyBean.getHostProxy());
        systemProperties.setProperty("http.proxyPort", proxyBean.getPortProxy());
        systemProperties.setProperty("https.proxyHost", proxyBean.getHostProxy());
        systemProperties.setProperty("https.proxyPort", proxyBean.getPortProxy());
        log.info("Saiu=================iniciaConexaoProxy()");
    }

    public void setConteudoRetorno(String conteudoRetorno) {
        this.conteudoRetorno = conteudoRetorno;
    }

    public void setPasspfrase(String pass) {
        this.passphrase = pass;
    }

    // **********************get's and set's
    public void setPath(String path) {
        this.path = path;
    }

    public void setProxyBean(ProxyBean proxyBean) {
        this.proxyBean = proxyBean;
    }

    public void setReceitaBean(ReceitaBean receitaBean) {
        this.receitaBean = receitaBean;
    }

    public void setTrustStore(String truststore) {
        this.truststore = truststore;
    }

    private boolean verificaParametros() {
        if (this.getPath().equals("")) {
            this.descricao_erro = "Falha ao verificar parametro Path";
            return false;
        } else {
            return true;
        }
    }

    public boolean executeConsultaHttps() {
        log.debug(">executeConsultaHttps()");
        LineNumberReader in = null;
        PrintWriter out = null;

        try {
            log.info("Conectando na URL: {}", path);
            HttpsURLConnection.setDefaultSSLSocketFactory(this.factory);

            URL url = new URL(path);
            if (getProxyBean() != null) {
                systemProperties = System.getProperties();
                iniciaConexaoProxy();
            }
            URLConnection httpsURLConnection = url.openConnection();
            httpsURLConnection.setConnectTimeout(getTimeout());
            httpsURLConnection.setReadTimeout(getTimeout());
            httpsURLConnection.connect();

            log.info("Conectado! Recebendo resposta... / Timeout = [ {} ] ms", getTimeout());

            BufferedReader inputStream = new BufferedReader(new InputStreamReader(httpsURLConnection.getInputStream()));
            in = new LineNumberReader(inputStream);

            String inputLine;

            while ((inputLine = in.readLine()) != null) {
                this.conteudoRetorno += inputLine + System.getProperty("line.separator");
            }

            // TODO retirar depois! apagando tracos do proxy
            if (getProxyBean() != null) {
                finalizaConexaoProxy();
            }
        } catch (Exception e) {
            this.descricao_erro = "Falha ao Conectar: " + e.toString();
            log.error(this.descricao_erro, e);
            return false;
        } finally {
            closeConnections(in, out, null);
        }
        log.debug("<executeConsultaHttps()");
        return true;
    }

    public int getTimeout() {
        return timeout == 0 ? DEFAULT_TIMEOUT : timeout;
    }

    /**
     * Sets a specified timeout value, in milliseconds.
     */
    public void setTimeout(int timeout) {
        this.timeout = timeout;
    }
}
