/*
 * Created on 20/02/2004
 */
package br.com.serasa.consultaprevia.bean.validator.filtro;

import java.util.ArrayList;
import java.util.List;

/**
 * @author dadario
 * 
 */
public class FiltroManager {

    private List<Filtro> filtros = new ArrayList<Filtro>();

    private int contador = 0;

    public void addFiltro(Filtro filtro) {
        this.filtros.add(filtro);
    }

    public Filtro getFiltro() {
        if (hasNext()) {
            Filtro filtro = filtros.get(contador);
            contador++;
            return filtro;
        }
        return null;
    }

    public boolean hasNext() {
        return contador < filtros.size();
    }

    public void reset() {
        filtros = new ArrayList<Filtro>();
        contador = 0;
    }
}
