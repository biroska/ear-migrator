/*
 * Created on 20/02/2004
 */
package br.com.serasa.tools;

import java.text.ParseException;

/**
 * @author dadario
 * 
 */
public class Formatter {

    public static String adicioneZerosAFrente(String valor, int quantidade) {

        int tamanho = valor == null ? 0 : valor.length();

        StringBuffer buffer = new StringBuffer();

        for (; tamanho < quantidade; tamanho++) {
            buffer.append("0");
        }

        if (valor != null) {
            buffer.append(valor);
        }

        return buffer.toString();
    }

    public static String bytesToStringHex(byte[] arrayBytes) {
        StringBuilder buf = new StringBuilder();

        int len = arrayBytes.length;

        for (int i = 0; i < len; i++) {
            byte2hex(arrayBytes[i], buf);
        }
        return buf.toString();
    }

    private static void byte2hex(byte b, StringBuilder buf) {
        char[] hexChars = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F' };
        int high = ((b & 0xf0) >> 4);
        int low = (b & 0x0f);
        buf.append(hexChars[high]);
        buf.append(hexChars[low]);
    }

    public static String dataCompleta(String dataNormal, Formato formato) throws ParseException {
        return Data.convert(dataNormal, formato, Data.DATA_COMPLETA_24H);
    }

}
