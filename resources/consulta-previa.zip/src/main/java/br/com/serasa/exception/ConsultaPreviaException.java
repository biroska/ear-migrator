/*
 * Created on Apr 7, 2005
 */
package br.com.serasa.exception;
/**
 * @author Trevisan
 * 
 */
public class ConsultaPreviaException extends Exception {

    /**
     * 
     */
    private static final long serialVersionUID = 4274966377590154417L;

    /**
     * 
     */
    public ConsultaPreviaException() {
    }

    /**
     * @param message
     */
    public ConsultaPreviaException(String message) {
        super(message);
    }

    /**
     * @param cause
     */
    public ConsultaPreviaException(Throwable cause) {
        super(cause);
    }

    /**
     * @param message
     * @param cause
     */
    public ConsultaPreviaException(String message, Throwable cause) {
        super(message, cause);
    }
}
