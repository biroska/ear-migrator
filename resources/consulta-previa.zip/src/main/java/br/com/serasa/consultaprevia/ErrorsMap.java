/*
 * Created on 16/12/2003
 */
package br.com.serasa.consultaprevia;

import java.util.HashMap;
import java.util.Map;

/**
 * Mapeia as mensagens de erros do Consulta Previa. Estava vindo com caracteres ? nos acentos, por isso mapeamos para
 * acentos em HTML. Atualizar os codigos caso ocorra alteracao.
 * 
 * @author riko
 * 
 *         Hugo - 02/03/2006: retirei todos os acentos HTML, pois estavam dando erro na hora de fazer o parse do xml
 */
public class ErrorsMap {

    private final static Map<String, String> errors = new HashMap<String, String>();

    static {
        /*//deprecated 01/04/08 Mensagens de erros estao em mensagens.properties
        errors.put("01", "CPF informado invalido. Emissao do Certificado nao permitida.");
        errors.put("02", "CPF informado inexistente nas bases de dados da SRF. Emissao do certificado nao permitida.");
        errors.put("03", "O CPF informado se encontra na situacao cadastral de CANCELADO nas bases de dados da SRF."
        		 + " Emissao do certificado nao permitida.");
        errors.put("04", "A data de nascimento informada e divergente da existente nas bases de dados da SRF."
        		 + " Emissao do certificado nao permitida.");
        errors.put("05", "O numero do titulo de eleitor nao foi informado. Emissao do certificado nao permitida.");
        errors.put("06", "O numero do titulo de eleitor informado e divergente do existente nas bases de dados da SRF."
        		 + " Emissao do certificado nao permitida.");
        errors.put("20", "CNPJ informado invalido. Emissao do certificado nao permitida.");
        errors.put("21", "CPF do responsavel informado invalido. Emissao do certificado nao permitida.");
        errors.put("22", "CNPJ informado inexistente nas bases de dados da SRF. Emissao do certificado nao permitida.");
        errors.put("23", "CPF do responsavel informado inexistente nas bases de dados da SRF."
        		 + " Emissao do certificado nao permitida.");
        errors.put("24", "O CNPJ informado se encontra na situacao cadastral de INAPTO nas bases de dados da SRF."
        		 + " Emissao do certificado nao permitida.");
        errors.put("25", "O CNPJ informado se encontra na situacao cadastral de CANCELADO nas bases de dados da SRF."
        		 + " Emissao do certificado nao permitida.");
        errors.put("26", "O CNPJ informado se encontra na situacao cadastral de SUSPENSO nas bases de dados da SRF."
        		 + " Emissao do certificado nao permitida.");
        errors.put("27", "O CPF do responsavel informado nao e igual ao do responsavel pela empresa nas bases"
        		 + " de dados da SRF. Emissao do certificado nao permitida.");
        errors.put("28", "O CPF do responsavel informado se encontra na situacao cadastral de CANCELADO nas bases"
        		 + " de dados da SRF. Emissao do certificado nao permitida.");
        errors.put("29", "A data de nascimento do responsavel informada e divergente da existente nas bases de"
        		 + " dados da SRF. Emissao do certificado nao permitida.");
        errors.put("40", "O Titulo de Eleitor informado possui mais de 12 digitos."
        		 + " Emissao do certificado nao permitida.");
        errors.put("41", "O CNPJ informado possui mais de 14 digitos. Emissao do certificado nao permitida.");
        errors.put("42", "O CPF informado possui mais de 11 digitos. Emissao do certificado nao permitida.");
        errors.put("43", "A data de nascimento deve ser informada com 8 digitos, no formato DDMMAAAA."
        		 + " Emissao do certificado nao permitida.");
        errors.put("50", "Tipo invalido. Emissao do certificado nao permitida.");
        errors.put("51", "Tipo invalido. Emissao do certificado nao permitida.");
        errors.put("52", "Numero do Titulo de Eleitor informado nao e numerico. Emissao do certificado nao permitida.");
        errors.put("53", "Numero do CNPJ informado nao e numerico. Emissao do certificado nao permitida.");
        errors.put("54", "Numero do CPF informado nao e numerico. Emissao do certificado nao permitida.");
        errors.put("55", "Data de nascimento informada contem caractere(s) invalido(s)."
        		 + " Emissao do certificado nao permitida.");
        errors.put("90", "Sistema temporariamente fora do ar. Tente mais tarde.");
        errors.put("91", "Sistema temporariamente fora do ar. Tente mais tarde.");
        errors.put("92", "Sistema temporariamente fora do ar. Tente mais tarde.");
        errors.put("93", "Sistema temporariamente fora do ar. Tente mais tarde.");
        errors.put("94", "Sistema temporariamente fora do ar. Tente mais tarde.");
        errors.put("95", "Sistema temporariamente fora do ar. Tente mais tarde.");
        errors.put("96", "Sistema temporariamente fora do ar. Tente mais tarde.");
        errors.put("97", "Sistema temporariamente fora do ar. Tente mais tarde.");
        errors.put("98", "Servidor com problemas. Tente mais tarde.");
        errors.put("99", "Certificado nao autorizado.");*/

        //Erros de conexao. Por exemplo, IOException
        errors.put(
            "-5",
            "<![CDATA[Servi�o de valida��o dos dados do titular do Certificado Digital provido pela  Receita Federal Brasileira esta indispon�vel no momento. Em caso de d�vida entre em contato com a SRF/RFB atraves do telefone 0800 728 2323]]>");
    }

    public static String getMsgError(String errorCode) {
        String errorMsg = errors.get(errorCode);
        return errorMsg == null ? "Ocorreu um erro executando consulta. Codigo do erro: " + errorCode : errorMsg;
    }
}
