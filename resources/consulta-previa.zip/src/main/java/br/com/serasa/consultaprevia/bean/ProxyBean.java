package br.com.serasa.consultaprevia.bean;

import java.util.Map;

/**
 * @author Tiziano 31/01/2006
 * 
 */
public class ProxyBean {
    private String hostProxy;

    private String passwordProxy;

    private String portProxy;

    private String userProxy;

    public ProxyBean() {

    }

    public ProxyBean(Map<String, String> paramMap) {
        setHostProxy(paramMap);
        setPortProxy(paramMap);
        setUserProxy(paramMap);
        setPasswordProxy(paramMap);
    }

    public String getHostProxy() {
        return this.hostProxy;
    }

    public String getPasswordProxy() {
        return this.passwordProxy;
    }

    public String getPortProxy() {
        return this.portProxy;
    }

    public String getUserProxy() {
        return this.userProxy;
    }

    private void setHostProxy(Map<String, String> paramMap) {
        this.hostProxy = (String) paramMap.get("host_proxy");
    }

    private void setPasswordProxy(Map<String, String> paramMap) {
        this.passwordProxy = (String) paramMap.get("password_proxy");
    }

    private void setPortProxy(Map<String, String> paramMap) {
        this.portProxy = (String) paramMap.get("port_proxy");
    }

    private void setUserProxy(Map<String, String> paramMap) {
        this.userProxy = (String) paramMap.get("user_proxy");
    }
}
