/*
 * Created on 20/02/2004
 */

package br.com.serasa.consultaprevia.bean.validator;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.owasp.esapi.CustomLogger;
import org.owasp.esapi.CustomLoggerFactory;

import br.com.serasa.consultaprevia.bean.validator.filtro.Filtro;
import br.com.serasa.consultaprevia.bean.validator.filtro.FiltroVazio;

/**
 * @author dadario
 */
public class ErroList {

	private CustomLogger log = CustomLoggerFactory.getLogger(this.getClass().getName());

    private Map<String, Object> mapaDeErros = new HashMap<String, Object>();

    private List<Object> ordemDeErros = new ArrayList<Object>();

    private Filtro filtroDaVez = FiltroVazio.INSTANCE;

    @SuppressWarnings("unchecked")
    public void add(String erro) {
        String nomeFiltro = filtroDaVez.getClass().getName();
        List errosDaVez = null;

        if (mapaDeErros.containsKey(nomeFiltro)) {
            errosDaVez = (List) mapaDeErros.get(nomeFiltro);
        } else {
            errosDaVez = new ArrayList();
            mapaDeErros.put(nomeFiltro, errosDaVez);
            ordemDeErros.add(nomeFiltro);
        }

        errosDaVez.add(erro);
    }

    public boolean contemErros() {
        return !mapaDeErros.isEmpty();
    }

    public List<Object> ordemDosErros() {
        return ordemDeErros;
    }

    public Map<String, Object> mapaDeErros() {
        return mapaDeErros;
    }

    @SuppressWarnings("unchecked")
    public List erros(String nomeFiltro) {
        return (List) mapaDeErros.get(nomeFiltro);
    }

    @SuppressWarnings("unchecked")
    public void addErroList(ErroList lista) {
        ordemDeErros.addAll(lista.ordemDeErros);

        Set chaves = lista.mapaDeErros().keySet();

        for (Iterator iter = chaves.iterator(); iter.hasNext();) {
            String element = (String) iter.next();
            Object listaDeErrosParaAdicionar = lista.mapaDeErros().get(element);

            if (mapaDeErros.containsKey(element)) {
                List listaDeErros = (List) mapaDeErros.get(element);
                listaDeErros.addAll((Collection) listaDeErrosParaAdicionar);
            } else {
                mapaDeErros.put(element, listaDeErrosParaAdicionar);
            }
        }
    }

    /**
     * @param filtro
     */
    public void setFiltroDaVez(Filtro filtro) {
        this.filtroDaVez = filtro;
    }

    @SuppressWarnings("unchecked")
    public void showMyself() {
        if (contemErros()) {
            Set<String> nomeCampos = mapaDeErros().keySet();
            for (Iterator<String> iter = nomeCampos.iterator(); iter.hasNext();) {
                String element = iter.next();
                log.info("Para o campo: {}", element);

                List<String> lista = (List) mapaDeErros().get(element);
                for (Iterator<String> iterator = lista.iterator(); iterator.hasNext();) {
                    String eachErro = iterator.next();
                    log.info(eachErro);
                }
            }
        } else {
            log.info("Erros n&atilde;o encontrados");
        }
    }
}
