package br.com.serasa.consultaprevia;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.owasp.esapi.CustomLogger;
import org.owasp.esapi.CustomLoggerFactory;

import br.com.serasa.consultaprevia.bean.ConsPreviaBean;
import br.com.serasa.consultaprevia.bean.validator.ErroList;
import br.com.serasa.consultaprevia.bean.validator.Validador;
import br.com.serasa.consultaprevia.bean.validator.filtro.FiltroManager;
import br.com.serasa.exception.TrataErros;
import br.com.serasa.helper.CommandImpl;
import br.com.serasa.util.DataUtil;
import br.com.serasa.xml.PostConsultaPreviaSAXParser;

/**
 * Description of the Class
 * 
 * @author Bruno
 * @created 15 de Julho de 2003
 */
public class ConsPreviaValidateCommand extends CommandImpl {

    protected ConsPreviaBean consPreviaBean;
    private CustomLogger log = CustomLoggerFactory.getLogger(this.getClass().getName());

    public boolean executeAction(HttpServletRequest request, Map<String, String> paramMap) throws Exception, TrataErros {
        // seta os campos da SRF como N�O edit�vel
        request.setAttribute(TAGLIBRARY_READONLY, "false");
        request.setAttribute(TAGLIBRARY_READONLY_SRF, "true");
    	boolean provConsSimples = DataUtil.isFromConsultaSimples(paramMap);  
    	
    	if (provConsSimples) {
    		log.info("> Is from consulta simples");
    	} else {
    		log.info("> Is NOT  from consulta simples");    		
    	}
    	
        consPreviaBean = new ConsPreviaBean();
        PostConsultaPreviaSAXParser CodigoXml = new PostConsultaPreviaSAXParser();
        consPreviaBean = PostConsultaPreviaSAXParser.processarXmlConsultaPrevia(request);
        CodigoXml.validarConsPreviaBean(consPreviaBean, provConsSimples);
        PostConsultaPreviaSAXParser.imprimir(consPreviaBean);
        // ConsPreviaBeanCreator.setBean(consPreviaBean, cons);

        FiltroManager manager = new FiltroManager();
        manager.addFiltro(new ConsultaPreviaFiltro());

        ErroList erros = Validador.validar(consPreviaBean, manager);

        if (erros.contemErros()) {
            addErros(erros);
        }
        return noErrors();
    }
}
