package br.com.serasa.tools;

import junit.framework.Assert;

import org.junit.Test;

public class VerifyTest {
	
	@Test
	public void testDefaultContructor() {
		Verify v = new Verify();
		Assert.assertNotNull(v);
	}
	
	@Test
	public void testValidDate() {
		Assert.assertTrue(Verify.isValidDate("02042011"));
	}
	
	@Test
	public void testValidDateAnoBisseto() {
		Assert.assertTrue(Verify.isValidDate("29022012"));
	}
	
	@Test
	public void testValidDateNaoAnoBisseto() {
		Assert.assertFalse(Verify.isValidDate("29022011"));
	}
	
	@Test
	public void testValidDateMesDiasInvalidos() {
		Assert.assertFalse(Verify.isValidDate("31112011"));
	}

	@Test
	public void testValidDateMesCom31Dias() {
		Assert.assertTrue(Verify.isValidDate("31012011"));
	}
	
	@Test
	public void testValidDateMesInvalido() {
		Assert.assertFalse(Verify.isValidDate("31132011"));
	}

	@Test
	public void testValidDateTamanhoInvalido() {
		Assert.assertFalse(Verify.isValidDate("3113201"));
	}
	
	@Test
	public void testValidCep() {
		Assert.assertTrue(Verify.isValidCep("07085045"));
	}
	
	@Test
	public void testValidCepVazio() {
		Assert.assertFalse(Verify.isValidCep(""));
	}
	
	@Test
	public void testValidCepComCaracterInvalidos() {
		Assert.assertFalse(Verify.isValidCep("07085@04"));
	}
	
	@Test
	public void testSRFValido() {
		Assert.assertTrue(Verify.isSRF("13"));
	}
	
	@Test
	public void testSRFInvalido() {
		Assert.assertFalse(Verify.isSRF("14"));
	}
	
	@Test
	public void testSRFVazio() {
		Assert.assertFalse(Verify.isSRF(""));
	}
	
	@Test (expected = NumberFormatException.class)
	public void testSRFNan() {
		Verify.isSRF("a");
	}
	
	@Test
	public void testDocumentValido() {
		Assert.assertTrue(Verify.isDocumentValid("43856789", "x"));
	}
	
	@Test
	public void testDocumentValidoSemDigito() {
		Assert.assertTrue(Verify.isDocumentValid("43856789", null));
	}
	
	@Test
	public void testDocumentVazio() {
		Assert.assertFalse(Verify.isDocumentValid("", ""));
	}
	
	@Test
	public void testDocumentComMais15Digitos() {
		Assert.assertFalse(Verify.isDocumentValid("1234567890987654", "x"));
	}
}
