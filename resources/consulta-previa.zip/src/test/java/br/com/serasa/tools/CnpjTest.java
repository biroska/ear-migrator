package br.com.serasa.tools;

import junit.framework.Assert;

import org.junit.Test;

public class CnpjTest {
	
	@Test
	public void testDefaultContructor() {
		Cnpj cnpj = new Cnpj();
		Assert.assertNotNull(cnpj);
	}
	
	@Test
	public void testCnpjValidoCom14Digitos() {
		Assert.assertTrue(Cnpj.isValid("62952049000100"));
	}
	
	@Test
	public void testCnpjValidoCom15Digitos() { 
		Assert.assertTrue(Cnpj.isValid("000000000000191"));
	}
	
	@Test
	public void testCnpjValidoVazio() { 
		Assert.assertFalse(Cnpj.isValid(""));
	}
	
	@Test
	public void testCnpjInvalidoCom14Digitos() { 
		Assert.assertFalse(Cnpj.isValid("62952049000111"));
	}
	
	@Test
	public void testCnpjInvalidoCom15Digitos() { 
		Assert.assertFalse(Cnpj.isValid("000000000000199"));
	}

}
