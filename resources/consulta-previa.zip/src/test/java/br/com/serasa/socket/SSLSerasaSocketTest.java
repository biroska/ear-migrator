package br.com.serasa.socket;

import java.io.InputStream;
import java.net.URL;
import java.security.KeyStore;
import java.util.HashMap;
import java.util.Map;

import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;

import org.junit.Assert;
import org.junit.Ignore;

import br.com.serasa.consultaprevia.bean.ProxyBean;

public class SSLSerasaSocketTest {

    @Ignore
    public void testExecuteConsultaHttps() throws Exception {
        Map<String, String> paramMap = new HashMap<String, String>();
        paramMap.put("host_proxy", "10.96.161.27");
        paramMap.put("password_proxy", "");
        paramMap.put("port_proxy", "3128");
        paramMap.put("user_proxy", "");
        ProxyBean proxyBean = new ProxyBean(paramMap);
        final String path = "https://www6.receita.fazenda.gov.br/consprev.asp?TipoCert=2&CPF=35894016134&CNPJ=04494444000181&DataNasc=27091970";
        final String truststore = "/br/com/serasa/consultaprevia/keystore/certreqstore.jks";
        final String pass = "serasa";
        SSLSocketFactory factory = createFactory(pass, truststore);
        
        SSLSerasaSocket socket = new SSLSerasaSocket(proxyBean, null, path, truststore, pass, factory);
        socket.setTimeout(1000);
        
        boolean status = socket.executeConsultaHttps();
        Assert.assertTrue(status);
        System.out.println(socket.getConteudoRetorno());
    }

    //copiado da classe CheckConsultaPrevia
    //private SSLSocketFactory createFactory(Properties parameterProperties) throws Exception {
    private SSLSocketFactory createFactory(String keystorePass, String keystore) throws Exception {
        //String keystorePass = parameterProperties.get("keystore_password").toString();
        //String keystore = parameterProperties.get("keystore_receita").toString();
        SSLSocketFactory factory = null;
        InputStream is = null;

        URL keystorePath = getClass().getResource(keystore);
        System.setProperty("javax.net.ssl.trustStore", keystorePath.toString().replace("file:", ""));
        System.setProperty("javax.net.ssl.trustStorePassword", keystorePass);

        try {
            SSLContext ctx = SSLContext.getInstance("TLS");
            KeyManagerFactory kmf = KeyManagerFactory.getInstance("SunX509");
            KeyStore ks = KeyStore.getInstance("JKS");
            char[] passphrase = keystorePass.toCharArray();

            is = getClass().getResourceAsStream(keystore);

            ks.load(is, passphrase);
            kmf.init(ks, passphrase);
            ctx.init(kmf.getKeyManagers(), null, null);
            factory = ctx.getSocketFactory();

        } finally {
            if (is != null) {
                is.close();
            }
        }

        return factory;
    }

}
